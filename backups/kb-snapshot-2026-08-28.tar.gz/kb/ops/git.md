# Git 规范

## 仓库
- 主仓: `/Users/zuo/kalistorik-site`（git）
- 玛门工作目录: `/Users/zuo/Desktop/家具/kalis-site/`（非 git）
- 共享记忆库: `/Users/zuo/Marcelzuo/kalis-memory`

## 规则
- git = 唯一真相源，动手前 pull
- commit: 英文 `type: description`，subject ≤50 字符，首字母小写，不用句号结尾
- 类型: `feat:` / `fix:` / `docs:` / `chore:`
- 删除文件用 `git rm`，不留 `.bak`
- 分支命名: `feat/描述`、`fix/描述`、`chore/描述`
