# 玛门工作日志

> 素材 · 图片 · 视频 · 代码。日追加、周瘦身、错即录。

## 日志卡索引

```text
结论：FB Reel 远程 QC 成片完成，v3 slideshow 已用于 FB #13
产物路径：~/Desktop/fb_remote_qc_20260818.mp4 · ~/Desktop/fb_inspection_slideshow_20260818_v3.mp4
下一步：等老板确认后续素材
任务链 id：fb-20260818-qc
```

---

## 📦 资产总览

### compose.js 视频引擎
- **路径：** `~/kalis-video/compose.js` · Node.js
- **功能：** Ken Burns zoompan+xfade，图片→1080×1920 MP4
- **特性：** 8方向 pan 预设、pre-scale+fill 防变形、Python/Pillow 标题卡、spawn 防 shell 注入
- **关键修正（07-21）：** 浮点除法抖动 → `(on-1)/${padFrames}.0`；预缩放 `scale=w:h:force_original_aspect_ratio=increase,crop=w:h` 防拉伸

### 音乐库 `~/kalis-video/audio/`
`ambient_electronic` 环境电子 · `industrial_cinematic` 工业电影 · `industrial_dark_ambient` 暗黑工业 · `minimal_techno` 极简 Techno · `music` 通用 · `sad_piano_heartbreaking` 悲情钢琴 · `sea_whisper_electronic` 海风电子

### 图像生成
- **API：** DashScope 通义万相 `wanx2.0-t2i-turbo` · 100张/天免费
- **流程：** POST → 轮询 task_id → 下载

### 错误记录
- **Logo 变体：** 只用 `~/.codex/assets/logo_kalis_white.png`
- **素材变形：** 1024 方图进 zoompan 拉伸 → ≥1440px + pre-scale 预处理

---

## 07-21 · FB Reel + 五路线视频 + compose.js 修正
- **FB Reel** V1→V2：pre-scale+fill 防变形、浮点除法去抖动、素材替换 → 9.3MB ✅
- **五路线**：A油画✅ B素描✅ C3D❌ D材质🥇 E拼贴V1+V2✅ — D 为最佳路线
- **compose.js**：浮点 `(on-1)/N.0`、pre-scale+fill 管线、spawn 防注入
- **生图**：39张 DashScope；**视频产出**：11 mp4，D v3 (7.7MB) 🥇

## 08-18 · FB Reel 远程 QC 电影级 5 镜
- **产出**：`~/Desktop/fb_remote_qc_20260818.mp4` · 1080×1920 · H.264+AAC · 30fps · CRF18 · 35.0s · 12.1MB
- **素材**：5 张 DashScope wanx2.0-t2i-turbo（720×1280 竖屏）· 车间远景/箱号贴/检验台/抽样开箱/扫线
- **曲目**：`industrial_cinematic.mp3`（-shortest 裁 35s + afade 2.5s）
- **字幕**：底部英文硬字幕（白字+深色硬阴影，Pillow），5 关键词，无中文
- **尾卡**：品牌暖白 #FAF8F5 + `logo_kalis_dark.png`
- **⚠️ 偏差**：wanx2.0 尺寸白名单最高竖屏 720×1280，无法满足 KB「≥1440px」；长边 1280 → 上采样 1.5x，已标注

## 08-18 · 验货家具拼图 slideshow v1→v3
- **任务**：桌面 4 张验货家具图拼竖屏 slideshow，迭代 3 版
- **v1**：scale 1080×810 + 上下暖白填充，crossfade 0.4s，每张 6s → 22.8s / 1.88MB
- **v2**：去白边填满（increase+crop 裁掉画面 ❌）→ 24.9s / 2.52MB
- **v3** ✅：完整显示 + 模糊背景铺满（前景 decrease 不裁不拉 + 背景 increase+crop+gblur=40），每张 5.8s + Logo 尾帧 2.5s → 24.1s / 2.47MB
- **4 图**：1067×800（三版同源）
- **曲目**：`ambient_electronic.mp3`；禁用 industrial_cinematic/sea_whisper；无 zoompan/文字/特效
- **自检**：v3 前景完整无裁切；背景条带 signalstats 有方差（模糊照片非纯色）；尾帧暖白 RGB 249,248,243 + Logo 居中
