# 路西法工作日志

> 文案 · 审查 · 知识库。每日追加、每周瘦身、犯错立即入 errors.md。
> 调度指令来自米迦勒，红线：不碰图/视频/代码/账号。

## 日志卡索引

```text
结论：C/D/B 三本英文小说双版本已交付
产物路径：桌面 DOCX（音之图书馆/梦织者学院/棱镜塔）
下一步：无（2026-07-29 悬空待办已取消）
任务链 id：novel-20260727
```

```text
结论：LI #16 已发（烂货到港后的实操六步）
产物路径：~/.codex/kb/kalistorik/social/linkedin.md
下一步：待 24h 后复查互动
任务链 id：li-20260819-16
```

```text
结论：LI #16 定稿待发布
产物路径：kalistorik/social/linkedin.md
下一步：等老板发布
任务链 id：li-20260819-16
```

## 2026-08-19 · LI #16

**主题：** 烂货到港后的实操六步（hold payment → document → triage 三桶 → proper remedies → platform claim → harden PO）
**字数：** ≤500；CTA 走 DM；Hashtag 5 个
**正文/归档：** `~/.codex/kb/kalistorik/social/linkedin.md` #16「✅ 已发」
**坑：** execute_code 挂走 terminal 兜底（已知）

---

## 2026-07-21 · 周一

### 核心交付
1. **LI #10** · 3 hidden production risks（deposit→loading 沉默期：排期挤占/物料掉包/QC 流于形式）· 词数 356 / 红线 7 项全过 / CTA 走 DM · 归档 linkedin.md → #10「📝 草稿」
2. **FB #9 Reel** · 工厂暗箱操作联动帖（Title+Caption+9 标签框三层，与 LI #10 互引）· 归档 facebook.md → #9「✅ 已发」
3. **Hashtag 三层策略** · 写进 `kalistorik/social/rules.md` §C · 精准 3-4 / 扩量 3-4 / 品牌 1 · 数量 LI ≤5 / FB Reels 8-10 / FB 照 ≤7

### 红线复述
LI ≤500 词 · FB 全部 Reels · Hashtag 层级错 = 流量错配

---

## 2026-07-27 · 三本英文小说重写立项+交付（5星双主角版）

### 立项（00:15–00:35）
- **派工例外：** 老板直派（米迦勒链路不顺，路西法直操盘一次性特权）
- **目标：** ①双主角（Luoyu+Luoxi 各执一半钥匙/真相）②三本主题统一 勇气(D)/牺牲(C)/信任(B) ③词表覆盖 ≥99.9% ④英文+中文双 DOCX ⑤英文版目录前加中英文概要
- **顺序：** C→D→B；执行 A+B+C+D 四杠杆（源头/选择/代价/响应）
- **路径：** 桌面同名 DOCX 覆盖；中文版等英文审定再做（避免返工）

### C 本（音之图书馆）
- **英文：** Ch31 重写为 "Three Hundred Years Later"（1200 词真剧情）；原词汇章挪 Appendix；DOCX 加封面+中英文概要+目录
- **覆盖：** 1512/1513=99.93%，短语 552/552=100%（比原 99.74% 更高）
- **中文：** 31 章全章翻译 + 附录 · 14,880 字（占 82%）· 人名约定 珞妤/珞析/塞拉拉/拉蒙 · Part 1-5+Ch1-31+Appendix 结构对齐英文版
- **坑：** execute_code 挂（已知）走 terminal；Appendix 漏段已用正则从原 Ch31 提取修复；Part 标题原不存在——从分析脚本推测插回

### D 本（梦织者学院）
- **策略：** 剧情已是 5 星（结构清晰/情感自然），词覆盖仅 39%、短语 11%——零改 Ch1-29，DOCX 末尾加 Appendix 包装成"梦织者学院银色走廊里 Luoyu 看见的记忆"
- **中文：** 29 章 · 14,902 字（占 80%）· 米迦勒恢复的 md 重建结构按 C 本规格 · Ch13/14 漏段已修复 · Part Two/Three/Four 标题补齐
- **坑：** 附录词汇必须分场景包装，不能直白列词

### B 本（棱镜塔）
- **英文：** 30 章 · 词覆盖 97.36% / 短语 93.30% · Appendix 包装按棱镜塔世界观（镜墙/楼层/飞行）
- **中文：** 30 章 · 翻译合并 Ch21-30（同主题/连续性）· Prism Heights → 棱镜塔
- **坑：** Ch30 正文原 DOCX 标题在正文缺失（米迦勒恢复时漏最后一段），已修复

### 收尾（03:30–04:05）
- **行距：** 三本英文版正文段落 1.5 倍 + 段后 6pt（C=484/D=493/B=621 段）· Appendix 紧凑
- **页码：** 三本英文版页脚居中 PAGE field（10pt），第 1 页起计含全部
- **备份入库：** 创建 `~/.codex/kb/study/luoyu/english/novels.md` 主索引（7.5KB）+ `luoyu-english-backup/` 子目录（552K · 含附录词汇/C 本新 Ch31/67 翻译稿/8 DOCX 脚本 · B 本翻译稿 7 个因合并 21-30 减少已说明）
- **坑：** line_spacing 必须 doc.save() 生效；第一版过滤太严跳过几乎所有段（只看样式），第二版用 first_chapter_pos 找 Ch1 正文起点精确分离；PAGE field 必须 OxmlElement+fldChar 不能直 text

---

## 2026-07-29 · 悬空待办取消
**老板令：** 每天任务当天结，不用提前做。三项悬空（LI复查/FB复查/下周三帖）取消。