# 团队通用

| 文件 | 内容 |
|:--|:--|
| `team.md` | 团队能力边界/分派 |
| `git.md` | git 规范 |
| `backup.md` | 备份规则 |
| `memory.md` | 记忆清理 |
| `web-search.md` | 联网 SOP |
| `errors.md` | 错误库 |
| `agents/` | 三兄弟工作日志 |
| `work-log/` | 米迦勒工作日志 |
