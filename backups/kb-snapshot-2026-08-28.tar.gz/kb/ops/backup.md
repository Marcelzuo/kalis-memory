# 备份规则

> 原则：只存不删；按用途分层；写时索引。

## 分层

| 类型 | 保留 |
|:--|:--|
| KB | 永久 |
| 工作日志 | 60 天 |
| 浏览器 trace | 7 天 |
| 临时截图 | 24 小时 |

过期压缩归档到 `~/.codex/backups/`，保留全文，不删。

## 大备份

- 收集规则文件。
- commit + push `Marcelzuo/kalis-memory`。
- 其他人只读。

## 小备份

- 触发：部署后 / 距上次 >24h。
- 路径：`~/.codex/backups/`，保留最近 10 个。
- 路西法自己管：`~/.hermes/backups/`。

## 共用备份库红线

- `Marcelzuo/kalis-memory` 内任何文件/目录，**删除前必须经老板同意**。
- 仅允许：新增、更新配置、只读查询。
- 禁止：删文件、删目录、改历史。

## 检查点

`~/.codex/state/checkpoint.json` 只记：

```json
{
  "owner": "michael",
  "current_task": "",
  "last_conclusion": "",
  "next_action": "",
  "updated": "YYYY-MM-DD"
}
```
