# 记忆与清理 SOP

> 路西法自清洁 + 记忆维护的统一规则。

## 一、MEMORY 字符红线

| 文件 | 上限 | 阈值 | 触发动作 |
|:--|--:|--:|:--|
| USER.md | 1375 | >70% | 主动压缩 |
| MEMORY.md | 2200 | >70% | 主动压缩 |

**MEMORY 只存两类**：
1. **个人引用**：OCR 路径、超分 venv、Vision API 限制等
2. **已知坑**：必须实时在每次会话都看到的 bug/限制

**MEMORY 不存**：
- 业务规则 → `~/.codex/kb/kalistorik/*.md`
- 操作 SOP → 各 skill 内
- 触发词速查 → 可直接从 KB 目录 `ls` 读出

## 二、写记忆铁律（2026-06-03）

- 加 USER/MEMORY 前必去重合并，**不许 append**
- MEMORY 顶部必放"触发词速查"
- 一类条目超过 3 条 → 拆出去建 KB 规则文件

## 三、自清洁流程

每次开工前 / 用户触发"清理/整理/瘦身"时执行：

| 步骤 | 命令 | 频率 |
|:--|:--|:--|
| 1. 杀 idle 进程 | `process list` + `kill` | 每日 |
| 2. 轮转日志 | `gzip` + truncate | 日志 >2M |
| 3. 清浏览器缓存 | `rm ~/.hermes/cache/screenshots/*.png` | 每周 |
| 4. 检查 MEMORY 字符 | `wc -c` + 百分比 | 每周 |
| 5. 检查协调仓 | `ls ~/.openclaw/workspace/coordination/` >50 文件必 archive | 每周 |
| 6. 备份 | `git` → `Marcelzuo/kalis-memory` | 距上次 >24h |

## 四、已知坑

### execute_code 工具挂

- **症状**：`_install_execute_code_approval_memory_patch` 参数不匹配
- **与 VPN/重启无关**——hermes 网关层 bug
- **处理**：**首次报错就走 `write_file + terminal` 兜底**，不再重试（重试无意义，浪费老板时间）
- 兜底脚本存 `/tmp/`，`python3` 跑

### 日志臃肿 = 失败信号

- 不要全量备份会话/任务产物
- 抽取关键摘要进 `~/.hermes/ledger/`（≤2KB/次）
- 日志分两类：**决策**（三段式，进 lucifer/mamen/satan/work-log）+ **事件**（单行时间戳，进 `events/YYYY-MM-DD.md`）
- 模板与红线见 `~/.codex/kb/kalistorik/content.md`
- SOP 见 `lucifer-v5-first-day-lessons §references/dump-handling.md`

## 五、关联

- 派工边界 → `~/.codex/kb/ops/team.md`
- 数学错题 → `~/.codex/kb/study/luoyu/math.md`
- 备份 → `~/.codex/kb/ops/backup.md`
