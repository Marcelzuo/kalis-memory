# 社媒架构 & 数据采集 SOP

> 米迦勒维护 · 每次采集按此流程执行

## 账号

| 平台 | 账号 | 类型 |
|:--|:--|:--|
| LinkedIn | `linkedin.com/in/kalistorik` | 个人号 |
| Facebook | `facebook.com/kalistorik` | Page |
| Instagram | `instagram.com/kalistorik` | 个人号 |

## 📡 数据采集标准流程

**方式**：AppleScript 驱动 Chrome（利用已登录态，免认证）

### 1. GA4 网站数据

```bash
# 打开 GA4 首页，提取 body 文本
osascript -e 'tell application "Google Chrome" to set URL of active tab of front window to "https://analytics.google.com/analytics/web/#/report-home/"'
sleep 5
osascript -e 'tell application "Google Chrome" to execute active tab of front window javascript "document.body.innerText.substring(0, 5000)"'
```

### 2. LinkedIn

```bash
# 个人主页 → 分析数据 + 帖子列表
URL: https://www.linkedin.com/in/kalistorik/
# 帖子详情页（获取展示量）:
URL: https://www.linkedin.com/in/kalistorik/recent-activity/all/
# 需要滚动加载: window.scrollBy(0, 500)
```

关键指标：档案浏览量、动态展示量、搜索分析、各帖展示/赞/评论

### 3. Facebook Page

```bash
URL: https://www.facebook.com/kalistorik
# 专业面板 / 成效分析（不稳定，可能 404）:
URL: https://www.facebook.com/kalistorik/?sk=insights
URL: https://business.facebook.com/latest/insights/people?asset_id=...
```

关键指标：粉丝数、帖子赞/评论/分享

### 4. Instagram

```bash
URL: https://www.instagram.com/kalistorik/
# ⚠️ IG 纯 JS 渲染，innerText 只能取到基础信息（帖数/粉丝/简介）
# 帖子级表现数据需手动查看或通过 Meta Business Suite
```

关键指标：帖数、粉丝数

### 5. 写入

数据采集完成后写入 `~/.codex/kb/kalistorik/social/data.md`，格式参照上期。

---

## 已知限制

| 问题 | 影响 | 替代方案 |
|------|------|----------|
| FB 专业面板常 404 | 无法获取展示/触达数据 | 可能需要 Business Suite 权限 |
| IG innerText 信息有限 | 无法获取帖子级互动 | 已记录基础数据，深度分析需人工 |
| LI 新帖展示量延迟 | 24h 内帖子不显示展示 | 等待 24h 后复查 |

---

## 翻译管线

- `base_url` = `http://127.0.0.1:19199`（deepseek2responses 代理）
- 绝不 kill/unload/改 plist
- Codex 更新后: `codex doctor` + `grep base_url` + `lsof -i:19199`

---

## 发帖最佳时段（2026-07-08 定稿）

### 时区换算

| 市场 | 夏令时 vs BJT | 当地9am = BJT |
|:--|:--|:--|
| 英国 | -7h | 16:00 |
| 西欧（德法荷比） | -6h | 15:00 |
| 美国东岸（纽约） | -12h | 21:00 |
| 美国西岸（LA） | -15h | 00:00(+1) |

### 三平台每日发布窗口（按顺序）

| 顺序 | 平台 | 北京时间 | 覆盖逻辑 | 内容角色 |
|:--:|:--|:--|:--|:--|
| ① | LinkedIn | 15:00–16:00 | 欧洲 9-10am 通勤+开工前刷 | 行业长文首发，建立叙事 |
| ② | Instagram | 18:00–19:00 | 欧洲 12-13pm 午休刷 | LI 后 3h，视觉化承接 |
| ③ | Facebook | 20:00–21:00 | 欧洲 14-15pm + 美东 8-9am 重叠 | LI 后 5h，收尾引发讨论 |

### 运营规则

- 三平台同话题**内容不同源不同形**，不是一篇发三处
- 同一话题 LI 首发 → 3h 后 IG → 5h 后 FB，避免内容撞车限流
- 节假日（圣诞/复活节/欧美国庆）停更
- 发布 4 周后查看后台粉丝活跃时段，微调 ±30 分钟
- 最优发布日：周二/三/四
---

## FB 发布规范（2026-07-21 新增）

### A. 发 Reels 时（有 Title + 标签框）

| 字段 | 内容 | 规则 |
|:--|:--|:--|
| **Title** | 视频信息流顶部叠加显示 | 20–40 英文单词，痛点前置，含关键词 |
| **Caption** | Title 下方完整描述框 | 完整文案，呼应 LI 话题 |
| **Topic** | 可选话题标签 | 填 `Furniture` 辅助算法分发 |
| **标签框** | Hashtags 专用字段 | 8–10 个，三层结构，FB 独立索引 |

运营加分：开启自动字幕、纯音乐配乐、标题关键词匹配画面内容。

### B. 发照片时

- Hashtags 放**第一条评论**（不是正文，不是标签框）

### C. Hashtag 三层结构（Reels 标签框用）

| 层级 | 数量 | 作用 | 示例 |
|:--|:--|:--|:--|
| 精准 | 3–4 | 锁定目标人群 | `#FurnitureSourcing` `#EuropeanFurnitureBuyers` |
| 扩量 | 3–4 | 泛行业触达 | `#QualityControl` `#ChinaManufacturing` |
| 品牌 | 1 | 沉淀私域 | `#KALISTORIK` |

- 总数 8–10 个，禁止堆 10+ 稀释流量
