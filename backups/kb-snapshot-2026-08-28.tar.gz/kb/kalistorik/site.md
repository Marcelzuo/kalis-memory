# 独立站全面增长策略 · 2025-2026

> 2026-07-10 · 玛门(SEO)+撒旦(多渠道)+路西法(全面路径)+米迦勒(现状审计) 四路汇总
> 2026-07-15 · 米迦勒核对实际代码，更新待办状态

---

## 一、kalistorik.com 现状审计（2026-07-15 核实）

| 项目 | 状态 | 说明 |
|------|:--:|------|
| H1 | ⚠️ | 2 个 H1（sr-only + visible），应合并为 1 个 |
| H2 结构 | ✅ | 10 个 H2，层次清晰 |
| JSON-LD Schema | ✅ | Product + Organization + WebSite 三个 |
| hreflang 多语言 | ✅ | 6 语言，子目录结构 |
| OG/Twitter Cards | ✅ | 完整 |
| Canonical | ✅ | 已改为 `/en`，JS 动态修正 |
| robots.txt | ✅ | sitemap 指向 kalistorik.com |
| HSTS | ❌ | 缺失 |
| CSP | ❌ | 缺失 |
| Blog | ✅ | `/blog/` 已建，1 篇帖 |
| llms.txt | ✅ | 已建 |
| 加载速度 | ✅ | TTFB 0.63s, 总计 1.1s |
| FAQPage Schema | ❌ | 已有 FAQ 区域但无对应 Schema |

---

## 二、Google SEO（玛门）

### 核心算法变化

| 更新 | 关键点 |
|------|--------|
| 2025-12 Core | 内容深度 + 实战经验权重加倍 |
| 2026-03 Spam | AI 生成外链精准打击 |
| 2026 E-E-A-T | 作者资质 + 真实案例 = 排名强化 |

### 内容策略

| 要素 | 基准 |
|------|------|
| 博客频率 | ≥1 篇/周（4 篇/月） |
| 博客长度 | 1500-2500 词 |
| 见效周期 | 6-12 个月 |
| B2B 博客效果 | 线索量 +67% |

### 技术 SEO

| 项目 | 优先级 |
|------|:--:|
| Schema 结构化数据 | 高（对 AI 搜索真正有效） |
| Core Web Vitals（LCP≤2.5s） | 高 |
| 长尾关键词矩阵 | 高（放弃大词） |
| llms.txt | ✅ 已完成 |
| 内容 30 天内更新 | 中（+3.2x AI 引用率） |

### 外链策略

| 方法 | 效果 |
|------|:--:|
| 原创数据报告 | ⭐⭐⭐（95% PR 选用） |
| 品牌提及回收 | ⭐⭐⭐（ROI 最高） |
| 行业媒体供稿 | ⭐⭐ |
| 禁止：PBN、付费链接、批量 guest post | ❌ |

---

## 三、SEO 外推广渠道（撒旦）

### 渠道排序

| 渠道 | CPL | 转化率 | 优先级 |
|------|:--:|:--:|:--:|
| LinkedIn 自然 | $0 | 2-6% | ⭐⭐⭐⭐⭐ |
| 邮件营销 | $0 | 2-5% | ⭐⭐⭐⭐ |
| YouTube | $0 | 1.5-3% | ⭐⭐⭐ |
| Google Ads | $30-80 | 2.5-4.5% | ⭐⭐⭐ |
| Europages/Kompass | 免费 | 1-3% | ⭐⭐ |
| Quora/Reddit/FB | $0 | <2% | ⭐⭐ |
| LinkedIn Ads | $75-150 | 2-6% | ⭐⭐ |

### AI 搜索优化（2025-2026 必做）

| 手段 | 权重 |
|------|:--:|
| Schema 结构化数据 | 高 |
| llms.txt | ✅ 已完成 |
| 权威媒体引用 | 高（胜于外链） |
| LinkedIn Pulse 内容 | 高（ChatGPT 偏爱）|
| 数据：40% B2B 决策者用 AI 调研 |

---

## 四、全面推广路径（路西法）

### 6 个月 0→询盘路线图

| 阶段 | 动作 |
|------|------|
| M1-2 | 技术 SEO 修复 + 5-10 篇核心内容页 + Schema |
| M3-4 | LinkedIn 内容 + 冷邮件 + 行业目录入驻 |
| M5-6 | 案例研究 + 白皮书 + 外链建设（DR>40） |

### 预算分配（$1500-3000/月）

| 项目 | 占比 |
|------|:--:|
| SEO 工具 | $100-200 |
| 内容外包 | $600-1000 |
| LinkedIn + 邮件工具 | $150-300 |
| 外链采购 | $300-500 |
| 广告测试 | $300-500 |

### ⛔ 常见坑

- 未做 SEO 基础就投广告 → 浪费
- 机器翻译多语言 → 降权
- 重博客轻案例 → 没转化
- 买垃圾外链 → Google SpamBrain 识别
- 忽略 E-E-A-T → 无信任信号

---

## 五、kalistorik.com 优化待办（2026-07-15）

| 优先级 | 事项 | 负责人 | 类型 |
|:--:|------|:--:|:--:|
| P2 | 双 H1 合并为 1 个 | 玛门 | 技术 |
| P1 | 加 FAQPage Schema | 玛门 | 技术 |
| P2 | 加 HSTS header | 玛门 | 安全 |
| P2 | 加 CSP header | 玛门 | 安全 |
| P3 | Europages/Kompass 免费入驻 | 撒旦 | 推广 |

> ✅ 已完成（7/10→7/15）：robots.txt、llms.txt、Blog 建站、canonical 修复

---
> 2026-07-15 米迦勒核对实际代码后更新 · 以此为准

---

## 六、老板决策（2026-07-10）

| 渠道 | 决策 | 理由 |
|------|:--:|------|
| YouTube 视频 | ❌ 排除 | B2B 找 B 端客户，视频模式不匹配 |
| Google Ads | ❌ 排除 | 付费点击吸引 C 端，ROI 低 |
| LinkedIn Ads | ❌ 排除 | 同上，暂不采用任何付费广告 |

### 有效渠道（仅免费 B2B 精准渠道）

| 渠道 | 状态 |
|------|:--:|
| SEO + Blog（长尾词） | ✅ |
| LinkedIn 自然内容 | ✅ |
| Europages/Kompass 免费目录 | 待入驻 |
| 邮件冷开发 | 待启动策略 |
| AI 搜索（Schema + llms.txt） | llms.txt ✅ · Schema 待补 |

## 七、邮件冷开发策略（2026-07-10）

### 与 LinkedIn DM 的区别

| 维度 | LinkedIn DM | 冷邮件 |
|------|:--:|:--:|
| 场景 | 社交平台被打扰 | 商务邮件 = 正常渠道 |
| 期待 | 用户不期待推销 | B2B 决策者每天处理邮件 |
| 价值感 | "要不要买我的服务" | "分享一个你可能关心的行业信息" |
| 风险 | 被举报/封号 | 被忽略/退信（无损失） |

### 邮件模板（信息型冷邮，不推销）

```
Subject: A quick note on [industry topic]

Hi [Name],

I follow your work at [Company] — noticed you oversee [category] sourcing.

Quick context: we inspect container-loads of furniture weekly from Chinese factories. Last month alone, we flagged three shipments that had passed third-party QC but had systemic issues: inconsistent leg heights, veneer swaps, and foam density substitutions.

We published a short write-up on what we are seeing — the kind of detail that never makes it into a standard AQL report.

Happy to share the link if useful. No pitch.

Best,
Max Zuo
KALIS TORIK
```

### 关键原则

- 不推销（No pitch）
- 提供有价值信息
- 短（≤5 句）
- 不提价格/折扣

### 工具

| 用途 | 推荐 |
|------|------|
| 找邮箱 | Hunter.io（免费 25 次/月）|
| 发邮件 | Gmail / 老板现有邮箱 |
| 追踪 | 暂不需要（回复少手动即可）|

### 频率

- 每周 ≤5 封（宁可少而精）
- 同一人 7 天无回复 → 发一次 follow-up → 再无回复停止
