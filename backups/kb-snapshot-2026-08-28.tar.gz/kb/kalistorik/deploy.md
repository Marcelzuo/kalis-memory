# 部署

> 详见 `~/.codex/deployment-reference.md`

## 🖼️ 图片 → 阿里云法兰克福（非 CF！）

| 项 | 值 |
|:--|:--|
| SSH | `ssh kali`（需 Clash 代理） |
| 图片源 | `~/Desktop/成品图-hq/` |
| 同步命令 | `rsync -avz ~/Desktop/成品图-hq/ kali:/www/wwwroot/kalistorik.com/images/` |

⚠️ **图片不在 Cloudflare 上，排查图片问题别去 CF 找！**

## Cloudflare Pages · kalistorik（代码/HTML 部署）

| 项 | 值 |
|:--|:--|
| 本地路径 | `/Users/zuo/kalistorik-site` |
| 项目名 | `kalistorik`（非 `kalistorik-site`） |
| 分支 | `master`（非 `main`） |
| URL | `https://kalistorik.pages.dev` |
| 命令 | `npx wrangler pages deploy . --project-name=kalistorik --branch=master` |

## 部署后验证
```bash
curl -sL -H 'User-Agent: Mozilla/5.0' 'https://kalistorik.pages.dev' -o /tmp/verify.html
```
