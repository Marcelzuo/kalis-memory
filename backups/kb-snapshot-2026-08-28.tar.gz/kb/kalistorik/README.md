# KALIS TORIK · 商业

| 文件 | 内容 |
|:--|:--|
| `brand.md` | 品牌/颜色/字体/Logo/素材铁律 |
| `content.md` | 内容红线/审查 |
| `deploy.md` | 部署 |
| `site.md` | 独立站/SEO |
| `algorithm.md` | 社媒算法/排名 |
| `social/plan.md` | 内容总纲 V7.7（唯一基准） |
| `social/rules.md` | 社媒账号/发布规范/采集 SOP |
| `social/data.md` | 社媒数据日报 |
| `social/linkedin.md` | LI 发帖记录 |
| `social/facebook.md` | FB 发帖记录 |
| `social/instagram.md` | IG 发帖记录 |
| `social/assets/` | 视频/图片素材（按平台分） |
| `clients/` | 客户名单 |
| `targets/li.md` | LI 目标 |
