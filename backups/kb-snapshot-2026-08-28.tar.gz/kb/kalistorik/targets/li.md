# LI 新客开发 · 本周目标清单（2026-07-08）

> 米迦勒挖目标 → 老板审核 → 老板执行
> 策略：评论破冰 → 2-3次互动后 → 发连接申请（不提KALIS TORIK）

## LinkedIn 搜索直达链接（老板一键打开）

| # | 搜索角色 | LI搜索链接 |
|:--|------|------|
| 1 | Furniture Buyer Europe | [点此搜索](https://www.linkedin.com/search/results/people/?keywords=furniture%20buyer&geoUrn=%5B%22101282730%22%5D) |
| 2 | Sourcing Coordinator Furniture | [点此搜索](https://www.linkedin.com/search/results/people/?keywords=sourcing%20coordinator%20furniture) |
| 3 | Junior Buyer Home & Furniture | [点此搜索](https://www.linkedin.com/search/results/people/?keywords=junior%20buyer%20furniture%20home) |
| 4 | Procurement Specialist Furniture EU | [点此搜索](https://www.linkedin.com/search/results/people/?keywords=procurement%20specialist%20furniture) |
| 5 | Category Manager Furniture | [点此搜索](https://www.linkedin.com/search/results/people/?keywords=category%20manager%20furniture) |

## 10 个目标画像 + 评论切入点

### 目标 1：家具零售商 Junior Buyer
- **画像**：欧洲中小型家具零售连锁的 Junior Buyer，2-5年经验，正在学习供应商管理
- **找法**：搜 "Junior Buyer furniture" + 筛选德国/荷兰/比利时
- **评论切入点**：他们常发"新一批样品到了"类的帖子 → 追问：*"Interesting collection. Curious — how do you handle batch consistency across showrooms when sampling from multiple suppliers?"*

### 目标 2：Sourcing Coordinator（采购协调员）
- **画像**：家具进口公司里负责跟单+物流的协调员，不是决策者但是执行者
- **找法**：搜 "Sourcing Coordinator furniture import"
- **评论切入点**：他们常转发行业报告或物流帖 → 补充：*"This matches what we see on the ground. The hidden variable most reports miss is factory production rhythm — a supplier that's great in March can be completely different in August during peak season."*

### 目标 3：Product Manager（家具产品经理）
- **画像**：中型家具品牌的 Product Manager，负责选品和供应商初筛
- **找法**：搜 "Product Manager furniture" + 筛选英国/北欧
- **评论切入点**：常发新品预告或设计趋势 → 提问：*"Beautiful design. Curious about the material sourcing side — do you find European oak supply chains more predictable than Asian hardwoods right now?"*

### 目标 4：Supply Chain Analyst（供应链分析师）
- **画像**：大型零售商的供应链分析岗，关注数据、效率、成本
- **找法**：搜 "Supply Chain Analyst furniture retail"
- **评论切入点**：他们常发数据分析帖或行业报告 → 追问：*"Great breakdown. One thing we've noticed: lead time variance on furniture imports isn't normally distributed — it's bimodal. Quick shipments from repeat orders vs long tails on new SKUs. Have you seen the same pattern in your data?"*

### 目标 5：Procurement Specialist（采购专员）
- **画像**：酒店/商业项目的家具采购专员，B2B大宗采购
- **找法**：搜 "Procurement Specialist furniture" + 筛选法国/意大利
- **评论切入点**：常发项目进展或招标信息 → 补充：*"Hospitality procurement has different rules from retail. The spec sheet is everything but the factory visit is where specs meet reality. Have you found any particular certification (FSC, OEKO-TEX) that actually correlates with fewer post-delivery issues?"*

### 目标 6：Independent Retailer Owner（独立家具店主）
- **画像**：在伦敦/柏林/阿姆斯特丹有1-3家店的独立零售商，亲自采购
- **找法**：搜 "furniture store owner" + 位置筛选欧洲主要城市
- **评论切入点**：他们爱发店铺日常、新货到店 → 评论：*"Love the curation. As someone who's been on the sourcing side for years, I'm always curious — what's the one thing you wish your Asian suppliers understood better about European retail customers?"*

### 目标 7：Interior Designer（室内设计师，指定采购）
- **画像**：做商业项目（酒店/办公/餐厅）的室内设计师，有家具采购话语权
- **找法**：搜 "interior designer commercial furniture procurement"
- **评论切入点**：常发项目完工照 → 评论：*"Stunning project. The furniture scale works perfectly with those ceiling heights. Do you typically spec custom dimensions or work within standard factory sizing?"*

### 目标 8：E-commerce Category Buyer（电商平台品类买手）
- **画像**：Wayfair/Made.com/Home24 等平台的家具品类买手
- **找法**：搜 "category buyer furniture e-commerce" + 筛选德国/英国
- **评论切入点**：常发品类分析或消费者趋势 → 提问：*"Interesting data on return rates. In our experience, the #1 return driver for imported furniture isn't quality — it's 'looks different from the photo.' Do you see the same split between quality returns vs expectation mismatch?"*

### 目标 9：Sustainability Manager（可持续采购经理）
- **画像**：关注 ESG 的家具公司采购/合规经理，是新兴岗位
- **找法**：搜 "sustainability manager furniture sourcing"
- **评论切入点**：常发 ESG 报告、碳足迹、FSC 认证 → 补充：*"Great framework. The challenge we see in practice: many excellent Chinese factories already meet EU sustainability standards in production, but their documentation pipeline isn't built for European audit expectations. The gap isn't practice — it's paperwork. Have you run into this?"*

### 目标 10：Trade Show Regular（展会常客）
- **画像**：经常参加米兰/科隆/巴黎家具展的采购决策者
- **找法**：搜 "Salone del Mobile" + "Möbelmesse" + "Maison & Objet" 相关帖子下的活跃评论者
- **评论切入点**：展会后发帖回顾 → 评论：*"Great roundup. Which trend did you see across multiple halls that you think will actually make it into retail, vs just being a show-floor moment?"*

## 评论原则（5条铁律）

| # | 规则 | 反例 |
|:--|------|------|
| 1 | 不提 KALIS TORIK | "We at KALIS..." ❌ |
| 2 | 不提自己是供应商 | "I can help you source..." ❌ |
| 3 | 只聊对方的内容 | 拐到自己业务 ❌ |
| 4 | 追问 > 陈述 | "How do you handle..." > "You should..." |
| 5 | 控制在 2-3 句 | 长篇大论 ❌ |

## 连接策略

| 互动次数 | 动作 |
|:--|------|
| 1-2 次高质量评论 | 对方已认识你 |
| 第 3 次互动后 | 发连接申请（不需备注，通过率高） |
| 5 个带备注名额 | 留给最高价值目标（KOL、关键潜在客户） |

## 每日执行节奏

- ⏱ 每天 10 分钟刷 LI
- 🎯 每天给 3-5 个目标用户的帖子写评论
- 📝 优先评论今天刚发的帖子（时效性高）
- 🔖 每次评论后截图或记录，便于追踪互动历史

---
**状态：** ⏳ 待老板审核
**下周：** 继续挖第二批 10 个目标
