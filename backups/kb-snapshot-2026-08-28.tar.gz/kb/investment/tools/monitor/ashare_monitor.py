#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A股短线盯盘提醒：按触发价位弹 macOS 通知，不做自动交易。"""
import json, os, subprocess, time
from datetime import datetime

CODES = '600262,300773,002824,301161,688591'
STOCKS = {
    '600262': {'name':'北方股份','buy_lo':15.0,'buy_hi':15.2,'stop':14.2,'t1':16.6,'t2':17.2,'breakout':15.95},
    '300773': {'name':'拉卡拉','buy_lo':15.3,'buy_hi':15.5,'stop':14.9,'t1':16.6,'t2':17.2,'breakout':16.3},
    '002824': {'name':'和胜股份','buy_lo':24.3,'buy_hi':25.0,'stop':22.8,'t1':26.5,'t2':27.5,'breakout':25.6},
    '301161': {'name':'唯万密封','buy_lo':28.6,'buy_hi':29.2,'stop':27.9,'t1':30.5,'t2':31.5,'breakout':30.0},
    '688591': {'name':'泰凌微','buy_lo':28.3,'buy_hi':29.0,'stop':28.0,'t1':30.5,'t2':31.5,'breakout':29.6},
}
LOG = '/Users/zuo/Desktop/A股盯盘日志_2026-08-26.txt'

def run(cmd):
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=25)
    return p.stdout

def notify(msg):
    try:
        subprocess.run(['osascript','-e',f'display notification "{msg}" with title "A股盯盘" sound name "Ping"'], timeout=5)
    except Exception as e:
        pass

def log(msg):
    line = f"{datetime.now():%H:%M:%S} {msg}"
    try:
        with open(LOG,'a',encoding='utf-8') as f:
            f.write(line+'\n')
    except Exception:
        pass
    print(line, flush=True)

def get_quotes():
    raw = run(f"opencli eastmoney quote {CODES} -f json 2>/dev/null")
    out = {}
    try:
        data = json.loads(raw)
        for x in data:
            out[x['code']] = x
    except Exception:
        pass
    return out

def get_indices():
    raw = run("opencli eastmoney index-board -f json 2>/dev/null")
    out = {}
    try:
        data = json.loads(raw)
        for x in data:
            out[x['name']] = x
    except Exception:
        pass
    return out

def main():
    last = {}
    log('=== 盯盘启动 ===')
    while True:
        now = datetime.now()
        t = now.time().hour*60 + now.time().minute
        in_session = (9*60+25 <= t <= 11*60+35) or (12*60+55 <= t <= 15*60+5)
        if not in_session:
            time.sleep(60)
            continue

        quotes = get_quotes()
        inds = get_indices()

        # 大盘生命线
        for key, idx, thresh in [('sh','上证指数',3800.0)]:
            v = inds.get(idx)
            if v:
                try: price = float(v['price'])
                except Exception: continue
                if price <= thresh:
                    k = 'sh_crash'
                    if time.time() - last.get(k,0) > 600:
                        msg = f"上证 {price:.2f} 跌破 3800，执行只卖不买"
                        notify(msg); log(msg); last[k]=time.time()

        for code, cfg in STOCKS.items():
            x = quotes.get(code)
            if not x: continue
            try: price = float(x['price'])
            except Exception: continue
            name = cfg['name']
            reasons = []
            if price <= cfg['stop']:
                reasons.append(f"{name} 跌破止损 {cfg['stop']}，先减半/清仓")
            elif cfg['buy_lo'] <= price <= cfg['buy_hi']:
                reasons.append(f"{name} 回踩买点 {price:.2f}，可小仓试")
            elif price >= cfg['t2']:
                reasons.append(f"{name} 到第二目标 {cfg['t2']}，止盈/清仓")
            elif price >= cfg['t1']:
                reasons.append(f"{name} 到第一目标 {cfg['t1']}，减 1/3")
            elif price >= cfg['breakout']:
                reasons.append(f"{name} 放量突破 {price:.2f}，观察承接")
            for msg in reasons:
                k = code + '|' + msg[:12]
                if time.time() - last.get(k,0) > 600:
                    notify(msg); log(msg); last[k]=time.time()
        time.sleep(45)

if __name__ == '__main__':
    main()
