#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A股盯盘助手 Web 版：本地网页 + 自动刷新，所有信息留在页面。"""
import json, os, subprocess, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import datetime

PORT = 8765
OPENCLI = '/Users/zuo/.npm-global/bin/opencli'
CODES = '600262,300773,002824,301161,688591'
STOCKS = {
    '301161': {'name':'唯万密封','buy_lo':28.6,'buy_hi':29.2,'stop':27.9,'t1':30.5,'t2':31.5,'breakout':30.0,'shares':100,'sell1':100,'sell2':0,'cost':2900},
    '688591': {'name':'泰凌微','buy_lo':28.3,'buy_hi':29.0,'stop':28.0,'t1':30.5,'t2':31.5,'breakout':29.6,'shares':200,'sell1':100,'sell2':100,'cost':5800},
    '002824': {'name':'和胜股份','buy_lo':24.3,'buy_hi':25.0,'stop':22.8,'t1':26.5,'t2':27.5,'breakout':25.6,'shares':100,'sell1':100,'sell2':0,'cost':2500},
    '300773': {'name':'拉卡拉','buy_lo':15.3,'buy_hi':15.5,'stop':14.9,'t1':16.6,'t2':17.2,'breakout':16.3,'shares':200,'sell1':100,'sell2':100,'cost':3200},
    '600262': {'name':'北方股份','buy_lo':15.0,'buy_hi':15.2,'stop':14.2,'t1':16.6,'t2':17.2,'breakout':15.95,'shares':200,'sell1':100,'sell2':100,'cost':3100},
}
last_request = time.time()
idle_limit = 600

def run_cmd(cmd):
    env = os.environ.copy()
    env['PATH'] = '/opt/homebrew/bin:/usr/local/bin:/Users/zuo/.npm-global/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=25, env=env)
        return p.stdout
    except Exception:
        return ''

def get_data():
    raw_q = run_cmd(f"{OPENCLI} eastmoney quote {CODES} -f json 2>/dev/null")
    raw_i = run_cmd(f"{OPENCLI} eastmoney index-board -f json 2>/dev/null")
    stocks = []
    indices = []
    try:
        stocks = json.loads(raw_q)
    except Exception:
        stocks = []
    try:
        indices = json.loads(raw_i)
    except Exception:
        indices = []
    # 落盘
    try:
        os.makedirs('/Users/zuo/.codex/kb/investment/data/quotes/2026/08/2026-08-26', exist_ok=True)
        with open('/Users/zuo/.codex/kb/investment/data/quotes/2026/08/2026-08-26/dashboard-quotes.jsonl','a',encoding='utf-8') as f:
            f.write(json.dumps({'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'stocks': stocks, 'indices': indices}, ensure_ascii=False)+'\n')
    except Exception:
        pass
    return {'time': datetime.now().strftime('%H:%M:%S'), 'stocks': stocks, 'indices': indices, 'stock_rules': STOCKS}

HTML = r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>A股盯盘助手</title>
<style>
:root{--up:#C62828;--down:#2E7D32;--bg:#0f172a;--panel:#1e293b;--line:#334155;--txt:#e2e8f0;--muted:#94a3b8;--gold:#C9A96E;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;padding:18px}
h1{font-size:22px;margin:0 0 6px}
.sub{color:var(--muted);font-size:13px}
.toolbar{display:flex;gap:10px;margin:14px 0;flex-wrap:wrap}
button{background:#334155;color:#fff;border:1px solid #475569;border-radius:8px;padding:8px 14px;font-size:14px;cursor:pointer}
button.primary{background:#2563eb;border-color:#3b82f6}
button.danger{background:#b91c1c;border-color:#dc2626}
button:active{opacity:.8}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:14px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px 12px}
.card .name{color:var(--muted);font-size:12px}
.card .val{font-size:18px;font-weight:700;margin-top:4px}
.card .chg{font-size:12px;margin-top:2px}
.up{color:#ff8a80}.down{color:#81c784}.flat{color:var(--muted)}
table{width:100%;border-collapse:collapse;background:var(--panel);border-radius:10px;overflow:hidden;font-size:13px}
th,td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}
th{background:#243244;color:#cbd5e1;font-weight:600}
tr:last-child td{border-bottom:none}
.signal{color:var(--gold)}
.log{background:#111827;border:1px solid var(--line);border-radius:10px;margin-top:16px;height:260px;overflow:auto;padding:10px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;line-height:1.6}
.log .t{color:#64748b}
.log .up{color:#ff8a80}.log .down{color:#81c784}.log .info{color:#93c5fd}.log .alert{color:#fbbf24}
.foot{color:var(--muted);font-size:11px;margin-top:8px}
</style>
</head>
<body>
<h1>A股盯盘助手 <span style="color:var(--gold)">Web版</span></h1>
<div class="sub" id="status">正在连接…</div>
<div class="toolbar">
  <button id="startBtn" class="primary">开始盯盘</button>
  <button id="pauseBtn">暂停</button>
  <button id="refreshBtn">立即刷新</button>
  <button id="clearBtn">清空日志</button>
  <button id="exitBtn" class="danger">退出服务</button>
</div>
<div class="grid" id="indexGrid"></div>
<div style="overflow:auto"><table id="stockTable"></table></div>
<div class="log" id="logBox"></div>
<div class="foot">每 30 秒自动刷新 · 只提醒，不自动下单 · 数据来自东财公开行情接口</div>
<script>
const rules = %RULES%;
const stockRows = %STOCK_ROWS%;
let timer = null;
let running = false;
let lastMsg = {};

const $ = id => document.getElementById(id);
function fmtTurnover(v){
  if(v >= 100000000) return (v/100000000).toFixed(2)+'亿';
  return (v/10000).toFixed(0)+'万';
}
function chgClass(v){ return v>0?'up':(v<0?'down':'flat'); }
function log(msg, cls='info'){
  const d=new Date();
  const ts=String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')+':'+String(d.getSeconds()).padStart(2,'0');
  const box=$('logBox');
  const row=document.createElement('div');
  row.innerHTML='<span class="t">'+ts+'</span> <span class="'+cls+'"></span>';
  row.children[1].textContent=msg;
  box.appendChild(row);
  box.scrollTop=box.scrollHeight;
  // 保留在 localStorage
  try{
    let arr=JSON.parse(localStorage.getItem('ashare_log')||'[]');
    arr.push({ts,msg,cls});
    if(arr.length>300) arr=arr.slice(-300);
    localStorage.setItem('ashare_log',JSON.stringify(arr));
  }catch(e){}
}
function restoreLog(){
  try{
    let arr=JSON.parse(localStorage.getItem('ashare_log')||'[]');
    arr.forEach(x=>{ const row=document.createElement('div'); row.innerHTML='<span class="t">'+x.ts+'</span> <span class="'+x.cls+'"></span>'; row.children[1].textContent=x.msg; $('logBox').appendChild(row); });
    $('logBox').scrollTop=$('logBox').scrollHeight;
  }catch(e){}
}
function signal(code, price, openp){
  const r=rules[code];
  if(!r) return ['等待','flat'];
  if(price <= r.stop) return ['跌破止损 '+r.stop+'：清仓 '+r.shares+'股','down'];
  if(r.sell2 > 0 && price >= r.t2) return ['第二目标 '+r.t2+'：卖 '+r.sell2+'股，清仓','up'];
  if(price >= r.t1) return [r.sell2 > 0 ? ('第一目标 '+r.t1+'：卖 '+r.sell1+'股') : ('第一目标 '+r.t1+'：卖 '+r.sell1+'股，清仓'),'up'];
  if(price >= r.breakout) return ['突破 '+price.toFixed(2)+'：空仓可买 '+r.shares+'股','up'];
  if(price >= r.buy_lo && price <= r.buy_hi){
    if(price < (openp*0.995)) return ['已到买点但弱于开盘，不接飞刀；站回 '+openp.toFixed(2)+' 再买 '+r.shares+'股','flat'];
    return ['回踩确认 '+price.toFixed(2)+'：买 '+r.shares+'股，约'+r.cost+'元（首次建仓，不再追加）','up'];
  }
  return ['持仓/等待','flat'];
}
function renderIndices(indices){
  const wanted=['上证指数','深证成指','创业板指','科创50','沪深300','中证500'];
  let html='';
  for(const name of wanted){
    const v=indices.find(x=>x.name===name);
    if(!v) continue;
    const chg=Number(v.changePercent||0);
    html+='<div class="card"><div class="name">'+name+'</div><div class="val">'+(+v.price).toFixed(2)+'</div><div class="chg '+chgClass(chg)+'">'+ (chg>0?'+':'')+chg.toFixed(2)+'%</div></div>';
  }
  $('indexGrid').innerHTML=html||'<div class="sub">指数暂无数据</div>';
}
function renderStocks(stocks){
  let html='<tr><th>名称</th><th>现价</th><th>涨跌%</th><th>今开</th><th>最高</th><th>最低</th><th>成交额</th><th>换手</th><th>信号</th></tr>';
  for(const code of stockRows){
    const x=stocks.find(s=>s.code===code);
    if(!x) continue;
    const chg=Number(x.changePercent||0);
    const price=Number(x.price||0);
    const sig=signal(code,price,Number(x.open||price));
    html+='<tr>'+
      '<td><b>'+rules[code].name+'</b></td>'+
      '<td>'+price.toFixed(2)+'</td>'+
      '<td class="'+chgClass(chg)+'">'+(chg>0?'+':'')+chg.toFixed(2)+'%</td>'+
      '<td>'+(+x.open).toFixed(2)+'</td>'+
      '<td>'+(+x.high).toFixed(2)+'</td>'+
      '<td>'+(+x.low).toFixed(2)+'</td>'+
      '<td>'+fmtTurnover(Number(x.turnover||0))+'</td>'+
      '<td>'+Number(x.turnoverRate||0).toFixed(2)+'%</td>'+
      '<td class="'+sig[1]+'">'+sig[0]+'</td>'+
      '</tr>';
  }
  $('stockTable').innerHTML=html||'<tr><td>暂无数据</td></tr>';
}
async function fetchOnce(manual){
  if(!manual && !running) return;
  try{
    const r=await fetch('/api/quotes');
    const d=await r.json();
    $('status').textContent='最后刷新 '+d.time+' · '+(running?'自动刷新中':'已暂停');
    renderIndices(d.indices||[]);
    renderStocks(d.stocks||[]);
    // 只在发生信号时记日志
    for(const code of stockRows){
      const x=(d.stocks||[]).find(s=>s.code===code);
      if(!x) continue;
      const price=Number(x.price||0);
      const s=signal(code,price,Number(x.open||price));
      const key=code+'|'+s[0];
      const now=Date.now();
      if(s[0]!=='持仓/等待' && s[0]!=='等待' && (!lastMsg[key] || now-lastMsg[key]>600000)){
        log(rules[code].name+' '+price.toFixed(2)+' '+s[0], s[1]);
        lastMsg[key]=now;
      }
    }
  }catch(e){
    $('status').textContent='连接失败：'+e;
  }
}
function start(){
  running=true;
  $('status').textContent='自动刷新中';
  log('=== 开始盯盘 ===','info');
  fetchOnce(true);
  clearInterval(timer);
  timer=setInterval(()=>fetchOnce(false),30000);
}
function pause(){
  running=false;
  clearInterval(timer);
  $('status').textContent='已暂停';
  log('=== 已暂停 ===','info');
}
$('startBtn').onclick=start;
$('pauseBtn').onclick=pause;
$('refreshBtn').onclick=()=>fetchOnce(true);
$('clearBtn').onclick=()=>{ $('logBox').innerHTML=''; localStorage.removeItem('ashare_log'); };
$('exitBtn').onclick=async()=>{ try{ await fetch('/shutdown'); }catch(e){} window.close(); };
restoreLog();
fetchOnce(true);
setInterval(()=>{ fetch('/api/heartbeat').catch(()=>{}); },60000);
</script>
</body>
</html>'''

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        global last_request
        last_request = time.time()
        if self.path.startswith('/api/quotes'):
            data = get_data()
            body = json.dumps(data, ensure_ascii=False).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == '/api/heartbeat':
            body = b'ok'
            self.send_response(200)
            self.send_header('Content-Type','text/plain')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == '/shutdown':
            body = b'ok'
            self.send_response(200)
            self.send_header('Content-Type','text/plain')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            threading.Thread(target=self.server.shutdown, daemon=True).start()
        else:
            stock_rows = json.dumps(list(STOCKS.keys()))
            html = HTML.replace('%RULES%', json.dumps(STOCKS, ensure_ascii=False)).replace('%STOCK_ROWS%', stock_rows)
            body = html.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)
    def log_message(self, *args):
        pass

def watchdog():
    global last_request
    while True:
        time.sleep(30)
        if time.time() - last_request > idle_limit:
            os._exit(0)

if __name__ == '__main__':
    server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    threading.Thread(target=watchdog, daemon=True).start()
    print('A股盯盘助手已启动: http://127.0.0.1:%d' % PORT, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
