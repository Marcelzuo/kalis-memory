# 投资目录

> 投资理财相关讨论、策略、数据全放这里。目录按“决策 / 规则 / 数据”三层拆开。

## 结构

| 目录 | 放什么 | 原则 |
|:--|:--|:--|
| `discussions/` | 老板与米迦勒的讨论、需求、决策过程 | 只记结论与背景，不混数据 |
| `strategies/` | 我的投资策略、交易系统、选股框架 | 只放规则与参数 |
| `strategies/active/` | 当前持仓、盯盘、触发价 | 唯一“现在状态” |
| `data/quotes/` | 个股查询快照，按日期 | 原始行情，不可篡改 |
| `data/market/` | 指数/板块/情绪快照 | 原始行情 |
| `data/research/` | 外部研究素材、四兄弟素材 | 来源保留 |
| `data/ledger/` | 查询/搜索台账 | 记录动作 |
| `analysis/` | 终审结论/研报 | 只放成稿 |
| `tools/` | 盯盘脚本等工具 | 代码与文档分开 |
| `archive/` | 旧版、已否决方案 | 只读 |

## 命名

- 日期型：`YYYY-MM-DD-<slug>.md`
- 当前态：`current-*.md`
- 行情快照：`data/quotes/YYYY/MM/YYYY-MM-DD/eastmoney-quote.json`

## 反应流程

1. 老板问 A 股 → 直接读 `strategies/active/current-watchlist.md` 和 `data/quotes/` 最新快照。
2. 要改规则 → 改 `strategies/` 后同步 `INDEX.md`。
3. 每次行情查询 → 落盘 `data/`。
4. 重大讨论 → 写 `discussions/YYYY-MM-DD-*.md`。
