# 搜索台账 · 美股/AI泡沫/经济危机调研

> 2026-08-25 启动。分工：米迦勒=估值+观点汇总；玛门=AI产业数据；撒旦=论坛情绪；路西法=权威机构预测+历史对比。

## 任务
近两个月全球看空美股/AI论调增多，有人预测半年至一年内美国爆发史上最严重经济危机（AI泡沫破裂触发）。要求四人全网搜索权威来源，联合给出判断。

## 台账
| site | query | count | status |
|:--|:--|:--:|:--|
| Reuters | AI bubble warning | 20 | done |
| Reuters | US recession 2026 warning | 13 | done |
| BIS/ECB/Taiwan/BoE | AI bubble / stress test | 5 | done |
| UBS/Goldman/Morgan Stanley | AI capex / datacenter debt | 6 | done |
| Science/Management Science | AI productivity | 2 | done |
| Reddit | AI bubble / crash 2026 | 15 | done |
| Hacker News | AI bubble recession | 25 | done |
| 知乎 | 美股 AI 泡沫 / 衰退危机 | 40 | done |
| Bloomberg | markets/opinions/news | 32 | done（news 空） |
| 雪球 | hot / stock | 15 | partial（登录墙） |

## 缺口
- 雪球讨论流、AAII、CNN Fear & Greed、VIX 直议未全覆盖。
- 下一轮兜底：AAII、CNN F&G、VIX、彭博快讯。
