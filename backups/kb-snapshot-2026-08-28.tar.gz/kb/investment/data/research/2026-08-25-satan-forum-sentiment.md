# 全球看空美股/AI 与经济危机论调 · 论坛与投资者情绪素材

> 采集日期：2026-08-25 · 采集范围：近两个月（2026-06 至 2026-08）
> 覆盖：Reddit（r/investing/r/wallstreetbets/r/stocks 跨算法）+ Hacker News + 雪球 + 知乎财经 + 路透 + 彭博
> 说明：仅素材，不给结论。每条标注来源。

---

## 1. Reddit · 零售投资者情绪（高热度榜单）

**核心信号：AI 泡沫叙事占据 r/wallstreetbets、r/Futurology、r/technology、r/europe 等多版热榜前 10，多个帖子评论数过千。**

| # | 帖子 | 热度 | 情绪方向 |
|---|---|---|---|
| 1 | r/pcmasterrace · PC enthusiasts when the first AI giant falls | 23667↑ 1614💬 | 🟡 中性 |
| 2 | r/antiai · THE BUBBLE ALREADY BURST. SPREAD THE FUCKING WORD. | 7976↑ 763💬 | 🔴 强烈看空 |
| 3 | r/OffMyChestPH · TANG INANG AI!!! FUUUUUCCCCCKK YOUUUUU!!!! | 6417↑ 258💬 | 🟡 中性 |
| 4 | r/pcmasterrace · Techbros on RAM/SSD supply be like | 5906↑ 396💬 | 🟡 中性 |
| 5 | r/wallstreetbets · AI bubble in a nutshell | 5842↑ 2774💬 | 🔴 强烈看空 |
| 6 | r/Futurology · AI Hyperscalers have pre-ordered almost all of 2027's global RAM supply, in | 5825↑ 1118💬 | 🟠 看空/警示 |
| 7 | r/food · Mashed Potato Birthday Cake [homemade] | 5171↑ 156💬 | ⚪ 无关 |
| 8 | r/technology · Apple Will "Watch Everything Burn" When AI Bubble Bursts - Ed Zitron | 4910↑ 530💬 | 🔴 强烈看空 |
| 9 | r/IllegallySmolCats · Update #1: Bubbles the tiny cloud kitten 🤍🫧☁️ | 4289↑ 105💬 | 🔴 强烈看空 |
| 10 | r/pcmasterrace · micron 12 seconds after the ai bubble bursts | 4190↑ 369💬 | 🔴 强烈看空 |
| 11 | r/Fire · 3 years later update: 31F, $5M net worth, retiring from OnlyFans | 4056↑ 815💬 | ⚪ 无关 |
| 12 | r/apple · Ed Zitron: Apple Will 'Watch Everything Burn' When the AI Bubble Bursts | 3411↑ 510💬 | 🔴 强烈看空 |
| 13 | r/europe · The AI Bubble Warning Just Came From Europe’s Central Bank - Gadget Review | 2843↑ 598💬 | 🔴 强烈看空 |
| 14 | r/technology · ‘My life’s screwed’: Korean investors stress out after AI bubble bursts | 2676↑ 250💬 | 🔴 强烈看空 |
| 15 | r/SECourses · 🚨 BOMBSHELL! Famous investor Steven Eisman exposes a terrifying reality.    | 2534↑ 338💬 | 🔴 强烈看空 |

**Reddit 关键叙事点（精选 7 条）：**

1. **r/wallstreetbets 「AI bubble in a nutshell」**(5842↑ **2774💬**) —— 全榜评论数最高，看空叙事的零售主战场
2. **r/Futurology** 「AI Hyperscalers pre-ordered almost all 2027 global RAM supply, prices ↑500%」(5825↑ 1118💬) —— 硬件供给侧看空论据
3. **r/technology 「Apple Will 'Watch Everything Burn' When AI Bubble Bursts - Ed Zitron」**(4910↑ 530💬) —— Ed Zitron（知名 AI 长期看空评论员）观点扩散
4. **r/europe 「The AI Bubble Warning Just Came From Europe's Central Bank」**(2843↑ 598💬) —— ECB 警告（机构层信号）
5. **r/technology 「Korean investors stress out after AI bubble bursts」**(2676↑ 250💬) —— 韩国散户已爆（先行指标）
6. **r/SECourses 「Steven Eisman exposes terrifying reality」**(2534↑ 338💬) —— Steven Eisman（《大空头》原型之一）公开看空
7. **r/antiai 「THE BUBBLE ALREADY BURST. SPREAD THE FUCKING WORD」**(7976↑ 763💬) —— 极端看空阵营

## 2. Hacker News · 技术圈内部讨论（更克制、更理性）

**核心信号：HN 整体「谨慎看空 + 显著分歧」，出现 Ask HN 专题讨论，技术从业者既怕泡沫也怕错过。**

| # | 帖子 | 热度 | 备注 |
|---|---|---|---|
| 1 | Every Tech Bubble Obeyed the Same Rule. AI Is Next [video] | 2↑ 0💬 |  |
| 2 | The AI boom: rational enthusiasm or the next dot-com bubble? | 1↑ 0💬 |  |
| 3 | Ask HN: What is the evidence for a stock market bubble in AI? | 11↑ 9💬 | 社区提问帖 |
| 4 | The AI boom: rational enthusiasm or the next dot-com bubble? | 3↑ 1💬 |  |
| 5 | I don't think AI is a bubble | 2↑ 2💬 | 🔵 看多反驳 |
| 6 | Ask HN: When will the AI bubble burst and eradicate all life in the planet? | 2↑ 1💬 | 社区提问帖 |
| 7 | PINE64 halts their open-source hardware manufacturing until the AI bubble b | 15↑ 1💬 | 实体经济影响 |
| 8 | Unitree Robotics IPO: "Embodied AI" Valuation Bubble? | 3↑ 3💬 | 中概机器人 IPO |
| 9 | What if the AI capex bubble may not be a bubble after all? | 1↑ 1💬 | 🔵 看多反驳 |
| 10 | AI is not just one bubble, strategist says – but a 'rolling sequence of bub | 14↑ 11💬 | 结构性多泡沫 |
| 11 | The Economist Who Predicted 2008 Crash Says AI Bubble Bursts Soon – Steve K | 1↑ 5💬 |  |
| 12 | The AI Bubble Is on Its Last Legs | 3↑ 0💬 | 看空观点文 |
| 13 | Did the AI Bubble Just Pop? | 2↑ 0💬 | 看空观点文 |
| 14 | Ask HN: Let's all sell our AI stocks, short Nvidia and pop the AI bubble | 8↑ 26💬 | 社区提问帖 |
| 15 | Ask HN: How to deal with gen AI as an gen AI-resistant person | 3↑ 2💬 | 社区提问帖 |
| 16 | AI Hype Is Running into Reality | 6↑ 1💬 |  |
| 17 | Zitron on CNBC talking Nvidia, unprofitable AI labs, and the Greater AI Bub | 5↑ 0💬 | 引用 Ed Zitron |
| 18 | The Railway Bubble vs. the AI Bubble (2025) | 5↑ 0💬 |  |
| 19 | When the AI Bubble Bursts, Who Will Be Left Holding the Bag? | 6↑ 0💬 |  |
| 20 | What happens when the AI bubble pops? | 25↑ 6💬 |  |
| 21 | The Vertical AI Bubble: We Keep Forgetting That LLMs Roll Dice | 4↑ 0💬 |  |
| 22 | What Does the Humbling of Leopold Aschenbrenner Mean for the A.I. Bubble? | 4↑ 2💬 | 原 AI 多头受挫 |
| 23 | Computers Are Just a Tool | 1↑ 0💬 |  |
| 24 | Forecasting the AI Bubble | 3↑ 0💬 | 看空观点文 |
| 25 | Enjoy the Bubble While It Lasts: The Secret Behind Your AI Bill | 6↑ 2💬 |  |

**HN 关键观点切片：**

- **「AI is not just one bubble, but a rolling sequence of bubbles」**(14↑ 11💬) —— 结构性多泡沫论
- **「Steve Keen: AI Bubble Bursts Soon」**(1↑ 5💬) —— 2008 预测者再次发声
- **「What happens when the AI bubble pops?」**(25↑ 6💬) —— HN 当次互动最高，泡沫破裂情景讨论
- **「I don't think AI is a bubble」(2↑ 2💬) + 「What if the AI capex bubble may not be a bubble?」(1↑ 1💬)** —— 多头反驳存在但热度低
- **「PINE64 halts open-source hardware manufacturing until the AI bubble bursts」**(15↑ 1💬) —— 实体经济已受影响
- **「Unitree Robotics IPO: Embodied AI Valuation Bubble?」**(3↑ 3💬) —— 中概机器人 IPO 被质疑
- **「Humbling of Leopold Aschenbrenner」**(4↑ 2💬) —— 知名 AI 看多派受挫（多翻空信号）

## 3. 路透社 · 主流财经媒体（克制、有反驳）

**核心信号：路透整体「承认风险但不为崩盘背书」，多家央行与机构点名警示。**

| 日期 | 标题（节选） | 性质 |
|---|---|---|
| 2026-07-29 | Could an AI market crash rival 2000 or 2008? Unlikely | 🟢 反驳看空 |
| 2026-07-17 | How Korean stocks turned from trusty bellwether to AI frenzy | 🔴 看空/警示 |
| 2026-07-09 | Taiwan central bank chief warns of AI bubble risk | 🔴 看空/警示 |
| 2026-06-30 | BIS dares to blaspheme as AI bubble fears wane | 🔴 看空/警示 |
| 2026-06-29 | China's robot quest triggers system overload | 🟡 中性 |
| 2026-06-29 | What's good for the US economy now may not be good for stocks | 🟡 中性 |
| 2026-06-25 | Don't confuse turbulence with decline. This market has legs | 🟡 中性 |
| 2026-06-04 | Whisper it, but the US jobs market may have turned a corner | 🟡 中性 |
| 2026-05-27 | Iran war deals blow to global markets’ ‘Gulf put’ | 🟠 风险提示 |
| 2026-03-26 | How Big Tech's $630 bln AI splurge will fall short | 🔴 看空/警示 |
| 2026-03-06 | Investors cling to shock-absorber trades as Iran war brings economic visibility  | 🟠 风险提示 |
| 2026-01-16 | Wall Street banks' fourth-quarter earnings in five charts | 🟡 中性 |
| 2025-12-29 | Tariffs, China, and the dollar: What Wall Street got wrong in 2025 | 🟠 风险提示 |
| 2025-12-15 | Bridgewater warns Big Tech's reliance on external capital to fund AI boom is 'da | 🟠 风险提示 |
| 2025-12-14 | The Week in Breakingviews: The war over Warner | 🟠 风险提示 |
| 2025-12-12 | Stocks drop as AI exuberance worries linger; US yields jump | 🟡 中性 |
| 2025-12-12 | Broadcom shares fall as margin warning sparks AI payoff worries | 🔴 看空/警示 |
| 2025-12-12 | AI jitters knock STOXX 600 lower, wiping out early‑week gains | 🔴 看空/警示 |

**路透关键信号：**

- **2026-07-09** 「Taiwan central bank chief warns of AI bubble risk」—— 台湾央行（与 AI 供应链最直接相关）发声
- **2026-06-30** 「BIS dares to blaspheme as AI bubble fears wane」—— 国际清算银行（央行中的央行）公开表态
- **2025-12-15** 「Bridgewater warns Big Tech's reliance on external capital to fund AI boom is 'dangerous'」—— 桥水点名
- **2025-12-08** 「Central bank body BIS raises concerns of gold and stocks double bubble」—— 双泡沫论
- **2026-03-26** 「How Big Tech's $630 bln AI splurge will fall short」—— 万亿级资本支出质疑
- **2026-07-29** 「Could an AI market crash rival 2000 or 2008? Unlikely」—— 主流媒体反驳（保留意见）

## 4. 彭博社 · 主流财经媒体

**核心信号：彭博市场头条已出现「Nvidia 多头被惩罚」「债市回归旧常态」「软件股盈利检验」等降温信号。**

| 板块 | 标题（节选） | 信号 |
|---|---|---|
| Markets | HSBC Buys at Least $3 Billion of Indian Debt on Deposit Rush | ⚪ 一般 |
| Markets | Stocks Climb as Bitcoin Hits $80,000 and Oil Falls: Markets Wrap | ⚪ 一般 |
| Markets | Hong Kong’s 2026 Luxury Rents to Rise 5% on Expat Wave, JLL Says | 🟡 中性/产业链 |
| Markets | Nvidia Stock Bulls Get Punished in the Run-Up to Earnings | 🔴 看空/降温 |
| Markets | Latest Oil Market News and Analysis for Aug. 25 | ⚪ 一般 |
| Markets | Laopu Gold Growth Slows as Bullion Slide Hits Luxury Demand | 🟡 中性/产业链 |
| Markets | Fed Should Not Hike Rates, JPMorgan AM Says | 🔴 看空/降温 |
| Markets | Major Indian Supermarket Chain Plans Record Rupee Bond Sale | ⚪ 一般 |
| Markets | India to Transfer Missile Technology to Domestic Manufacturers | ⚪ 一般 |
| Markets | China’s IPO Rush Is Showing Strain With Pace Nearing 2023 Frenzy | ⚪ 一般 |
| Markets | UBS Expands Push to Leverage Client Cash in Middle East Banks | ⚪ 一般 |
| Markets | Software Stocks Get an Earnings Gut Check After Hot Summer Rally | 🔴 看空/降温 |
| Markets | What Trump's New $100,000 H-1B Visa Fee Could Mean for India | ⚪ 一般 |
| Markets | China Defends Cooperation With Iran, Warns Against Sanctions | ⚪ 一般 |
| Markets | Senegal Lawmakers Order Probe Into €1 Billion Total Return Swaps | ⚪ 一般 |
| Markets | Horizons Middle East & Africa 8/25/2026 | ⚪ 一般 |
| Markets | Ireland’s AIB Turns to Santander for SRT Tied to Project Finance | ⚪ 一般 |
| Markets | Siemens Energy Taps Goldman Sachs for Steam Turbine Stake Sale | ⚪ 一般 |
| Markets | European Stocks Advance as Oil Prices Drop; Siemens Energy Up | ⚪ 一般 |
| Markets | Nvidia To Move Markets More Than Warsh: 3-Minute MLIV | ⚪ 一般 |
| Opinions | Quantum Computing: The Race to 100 Error-Corrected Qubits Is Defining Progress | 🟡 中性/产业链 |
| Opinions | US Unemployment Rate Would Be Less Representative With Private Data | ⚪ 一般 |
| Opinions | The Real Reason Why Walmart Is Slashing Prices by $2.9 Billion | 🟡 中性/产业链 |
| Opinions | Kalshi and Polymarket Want a Bite of the AI Boom | 🟡 中性/产业链 |
| Opinions | ‘Pretend I’m on the Ballot’ May Not Help Darline Graham Win | ⚪ 一般 |
| Opinions | More Cheese, Please: Japanese Opt for ‘Guilty Consumption’ | ⚪ 一般 |
| Opinions | Who Should Control Anthropic? | ⚪ 一般 |
| Opinions | Alibaba’s $10 Billion Share Sale Doesn’t Stun Just Michael Burry | 🟠 看空人物出现 |
| Opinions | Voters Hate Data Centers Even More Than Corruption | ⚪ 一般 |
| Opinions | Pete Hegseth Misreads Military Bureaucracy and Risks Safety Standards | ⚪ 一般 |
| Opinions | Trump's War on Fraud Is Targeting the Wrong White Collar Crime | ⚪ 一般 |
| Opinions | US Bond Market Is Returning to the Old Normal | 🔴 看空/降温 |

**彭博关键信号：**

- **「Nvidia Stock Bulls Get Punished in the Run-Up to Earnings」** —— Nvidia 多头财报前被清洗
- **「Fed Should Not Hike Rates, JPMorgan AM Says」** —— 摩根资管反对加息（衰退隐忧）
- **「Software Stocks Get an Earnings Gut Check After Hot Summer Rally」** —— 软件股夏季大涨后被检验
- **「US Bond Market Is Returning to the Old Normal」** —— 债市回归旧常态（避险资金进场信号）
- **「Alibaba's $10 Billion Share Sale Doesn't Stun Just Michael Burry」** —— Michael Burry（《大空头》主角）再次现身
- **「Voters Hate Data Centers Even More Than Corruption」** —— AI 基建政治风险
- **「Nvidia To Move Markets More Than Warsh」** —— Nvidia 仍是市场核心定价者

## 5. 雪球 · A 股 / 港股情绪

**核心信号：雪球 hot/feed 需登录（HTTP 400，未取到一手讨论流），仅拿到 hot-stock 热门股清单。**

**热门股清单（非 AI 板块主导）：**

| # | 代码 | 名称 | 涨跌 |
|---|---|---|---|
| 1 | SZ000568 | 泸州老窖 | -0.91% |
| 2 | SZ300308 | 中际旭创 | -2.78% |
| 3 | SH688836 | C宇树-W | -0.05% |
| 4 | 03690 | 美团-W | -6.65% |
| 5 | SH603259 | 药明康德 | 3.31% |
| 6 | SZ000858 | 五粮液 | 0.06% |
| 7 | SH688356 | 键凯科技 | 7.59% |
| 8 | SZ002837 | 英维克 | 10.01% |
| 9 | SZ002821 | 凯莱英 | 10.00% |
| 10 | SZ000792 | 盐湖股份 | -3.62% |
| 11 | SH603516 | 淳中科技 | 3.41% |
| 12 | 00700 | 腾讯控股 | 0.45% |
| 13 | SZ002371 | 北方华创 | -1.06% |
| 14 | 02268 | 药明合联 | 14.83% |
| 15 | SZ300750 | 宁德时代 | -2.88% |

**观察：**

- 雪球 hot-stock 榜无明显 AI 集中板块；机器人（C宇树-W = Unitree）+ 光模块（中际旭创、英维克）+ 锂电（盐湖、宁德）分散
- 部分个股 -10%（英维克跌停），市场情绪分化
- 美团 -6.65% 单日大跌，消费疲软信号
- **雪球讨论流（hot/feed/comments）受登录限制无法抓取** → 中文专业投资者社群情绪数据缺失，需 DDG 兜底

## 6. 知乎 · 中文投资者情绪（重灾区，看空压倒性主导）

**核心信号：知乎出现多个 1000+ 赞看空帖，「2026 金融危机」「美股崩盘」「AI 泡沫」成爆款话题；多头反驳成被嘲讽对象。**

**看空主题热度榜（按点赞排序）：**

| 点赞 | 类型 | 作者 | 标题 |
|---|---|---|---|
| 2174 | answer | @王HK | 投资大王罗杰斯预言，2026年将会爆发金融危机，这个预言发生的概率是多大？ |
| 1557 | answer | @TopView | 2026年你认为美股有多大可能崩盘？为什么？ |
| 1222 | answer | @Stray birds | 2025年底或2026年上半年，美国会出现类似“2008年金融海啸”那样级别的金融危机吗？ |
| 1055 | answer | @索利文斯顿 | 美股是不是快崩盘了? |
| 1040 | answer | @王克丹 | 美、日、韩、中股市都在下跌，2026 年真会如罗杰斯所预言发生金融危机吗？ |
| 568 | answer | @安好心 | 为什么知乎上这么多人否定美股会崩盘？ |
| 418 | article | @斯文 | 2026年会爆发严重的金融危机？ |
| 259 | answer | @时代之 | 诺奖得主预警美股处「特殊时点」，AI「准泡沫」将破裂，这意味着什么？ |
| 226 | article | @若丹 | 未来20年推演（二）：2026-2030，滞胀与撕裂——从第一波冲击到美元信用裂缝 |
| 214 | answer | @浅笑清风丶 | 2026年发生类似2008年那样的金融危机概率大吗？ |
| 186 | answer | @海船上的渔夫 | 你觉得2026年~2027年，世界会变成什么样子？ |
| 159 | article | @老夫亦禅 | 预警！2026 年 6 月全球性金融危机要来了…… |
| 93 | answer | @浪羁 | 高志凯教授说今年下半年到2027年将会爆发全球性的经济危机，普通人该怎么做？ |
| 65 | answer | @唐先生 | 美国AI泡沫破裂后会发生什么？ |
| 44 | article | @忠哥新视界 | 深度分析|美国今年十月份将爆发席卷全球的金融危机 |

**知乎关键叙事（分四组）：**

**A. 「2026 金融危机」爆款话题（罗杰斯预测反复出现）：**

- 「投资大王罗杰斯预言，2026年将会爆发金融危机」—— **2174 赞 / 469 赞 / 463 赞 / 214 赞**（多个变体）
- 「2025年底或2026年上半年，美国会出现类似2008年金融海啸」—— **1222 赞 / 1040 赞 / 1557 赞 / 100 赞**（多变体）
- 「2026年你认为美股有多大可能崩盘？」—— **1557 赞 / 769 赞**（直接民意调查式，赞数即看空人数）
- 「2026年会爆发严重的金融危机？」—— 418 赞（文章）
- 「2026 年 6 月全球性金融危机要来了」—— 159 赞（具体时间点）
- 「美国今年十月份将爆发席卷全球的金融危机」—— 44 赞（更激进时间预测）

**B. AI 泡沫 + 一/两年内破裂：**

- 「美股是不是快崩盘了?」—— 1055 赞
- 「AI泡沫还能持续多久？」—— 105 赞 / 80 赞 / 28 赞（多答）
- 「美国AI泡沫破裂后会发生什么？」—— 65 赞
- 「美股AI泡沫已经开始清算硬着陆了」—— 38 赞
- 「一夜蒸发万亿！英伟达7连跌，AI泡沫破裂？」—— 0 赞但话题性强
- 「2026年秋天，美股AI泡沫的'完美风暴'正在成型」—— 1 赞（具体时间预测）

**C. 名人/机构预测汇总（被反复引用）：**

- **Jim Rogers（罗杰斯）**：2026 金融危机（多个 1000+ 赞答案核心引用）
- **高志凯**（中国政治评论员）：广州博览会预测「美国 AI 泡沫一年内破灭，金融海啸」（93 赞 / 39 赞 / 28 赞 / 4 赞）
- **诺奖得主**（未指名，疑 Krugman）：「特殊时点，AI 准泡沫将破裂」（259 赞）
- **Ray Dalio（达利欧）**：桥水对话「美股已出现典型 AI 泡沫迹象」（9 赞，但机构引用）
- **宋鸿兵**（货币战争作者）：「中国 AI 刺痛美国 AI 泡沫」（31 赞）

**D. 知乎元叙事（反向情绪指标）：**

- **「为什么知乎上这么多人否定美股会崩盘？」（568 赞）** —— 反向看空：这么多人反驳崩盘，说明看空已成共识，反向解读为崩盘将至
- 「美股 AI 泡沫硬着陆」（38 赞）—— 看空已被描述为正在发生

## 7. 知名看空人物 / 机构汇总

| 人物 / 机构 | 身份 | 主要观点 | 出现来源 |
|---|---|---|---|
| **Michael Burry** | 《大空头》主角 | 阿里巴巴增发不意外（隐含看空中国/全球 AI） | Bloomberg |
| **Steven Eisman** | 《大空头》原型之一 | 「暴露可怕现实」 | r/SECourses |
| **Ed Zitron** | 科技评论员、长期 AI 看空派 | 「Apple 将眼看着一切燃烧」 | r/technology, HN |
| **Steve Keen** | 预测 2008 危机的经济学家 | 「AI 泡沫将很快破裂」 | HN |
| **Ray Dalio** | 桥水创始人 | 「美股已出现典型 AI 泡沫迹象」 | 知乎转引 |
| **Jim Rogers** | 量子基金联合创始人 | 「2026 爆发金融危机」 | 知乎多帖 |
| **高志凯** | 中国政治评论员 | 「2026 H2–2027 全球经济危机」 | 知乎多帖 |
| **Leopold Aschenbrenner** | Situational Awareness 作者（原 AI 多头） | 「被 humbling」 | HN |
| **BIS** | 国际清算银行（央行中的央行） | 黄金+股市双泡沫担忧 | Reuters |
| **Bridgewater** | 达利欧对冲基金 | Big Tech 依赖外部资本「危险」 | Reuters |
| **Taiwan 中央银行** | 央行 | AI 泡沫风险警告 | Reuters |
| **欧洲央行 (ECB)** | 央行 | AI 泡沫警告 | r/europe |
| **JPMorgan Asset Mgmt** | 资管 | 反对美联储加息（衰退隐忧） | Bloomberg |

## 8. 市场恐慌情绪指标类讨论

| 指标 / 信号 | 讨论内容 | 来源 |
|---|---|---|
| **VIX / 波动率** | 路透多次提及「shock-absorber trades」「visibility to zero」「clinging to hedges」 | Reuters |
| **资金流向** | 黄金与股市双泡沫（BIS 警告）→ 资金已分流至避险资产 | Reuters |
| **债市回归「旧常态」** | 彭博社论「US Bond Market Is Returning to the Old Normal」 | Bloomberg |
| **Nvidia 散户清洗** | 「Nvidia Stock Bulls Get Punished in the Run-Up to Earnings」 | Bloomberg |
| **韩股散户崩盘** | 「Korean investors stress out after AI bubble bursts」 | r/technology |
| **半导体硬件涨价** | 「AI Hyperscalers pre-ordered 2027 global RAM supply, prices +500%」 | r/Futurology |
| **AI 基建政治风险** | 「Voters Hate Data Centers Even More Than Corruption」 | Bloomberg |
| **VIX 直接大标题** 未单独命中，多在衍生指标（个股波动、债券、黄金、汇率）中折射 | | 间接信号 |

## 9. 搜索台账（site / query / count / status）

| # | 站点 | 命令 | 查询 / 参数 | 状态 | 命中 |
|---|---|---|---|---|---|
| 1 | reddit | search | `AI bubble` --time month --sort top | ✅ | 15 |
| 2 | reddit | search | `recession crash 2026 prediction` | ❌ JSON parse error | 0 |
| 3 | reddit | search | `stock market crash 2026` | ❌ 同上（reddit 临时返回 HTML） | 0 |
| 4 | hackernews | search | `AI bubble recession 2026` | ⚠️ 命中弱 | 1 |
| 5 | hackernews | search | `AI bubble` --sort date | ✅ | 25 |
| 6 | xueqiu | hot | (无 query) | ❌ HTTP 400 需登录 | 0 |
| 7 | xueqiu | hot-stock | (无 query) | ✅ | 15（仅股票代码） |
| 8 | zhihu | search | `美股 AI 泡沫` | ✅ | 20 |
| 9 | zhihu | search | `美国经济衰退 2026 危机` | ✅ | 20 |
| 10 | reuters | search | `AI bubble warning` | ✅ | 20 |
| 11 | reuters | search | `US recession 2026 warning` | ⚠️ 命中率低 | 13 |
| 12 | bloomberg | markets | --limit 20 | ✅ | 20 |
| 13 | bloomberg | opinions | --limit 20 | ✅ | 12 |
| 14 | bloomberg | news | --limit 20 | ❌ 空返回 | 0 |

**预算消耗：**

- **AI 站（Hacker News 按非严格 AI 站算）**：2/2
- **非 AI 站**：reddit 2/2（1 成功 + 2 失败重试），xueqiu 2/2（1 失败 + 1 成功），zhihu 2/2，reuters 2/2，bloomberg 2/2（1 失败 + 1 成功）
- **总查询：14 次**（因 reddit 临时 HTML 故障做了 1 次额外重试）

**已知数据缺口（建议下一轮兜底）：**

- ❌ **xueqiu hot/feed/comments** 全部需登录 → 中文专业投资者社群情绪数据缺失
- ❌ **reddit 第二次搜索 JSON 解析错误**（reddit 临时返回 HTML） → recession 类讨论数据较弱
- ❌ **bloomberg news** 空返回 → 当日快讯类内容缺失
- ⚠️ **VIX 直接讨论** 未单独命中，多在衍生指标中出现
- ⚠️ **雪球「讨论流」** 缺失 → 建议下一轮用 DDG 抓 xueqiu.com 公开帖标题/snippet 兜底
- ⚠️ **Fear & Greed Index、AAII 散户调查** 等专业情绪指标未抓取 → 建议下一轮加 AAII / CNN F&G / Investors Intelligence
