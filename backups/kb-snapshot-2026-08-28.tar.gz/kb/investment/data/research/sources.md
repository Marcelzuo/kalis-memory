# 投资数据源总表（2026-08-27 扩充）

> 目的：不做东财单一来源。每次行情/政策/新闻分析，按主题从下表中选多个源交叉验证。

## 一、官方/监管（政策市第一优先）
- 证监会 `csrc.gov.cn`：监管政策、处罚、IPO/再融资。
- 央行 `pbc.gov.cn`：货币政策、LPR、流动性。
- 财政部 `mof.gov.cn`：财政、特别国债、税收。
- 国家统计局 `stats.gov.cn`：CPI/PPI/PMI/社零/工业数据。
- 发改委 `ndrc.gov.cn`：产业政策、价格政策。
- 商务部 `mofcom.gov.cn`：外贸、关税、出口管制。
- 海关总署 `customs.gov.cn`：进出口数据。
- 上交所 `sse.com.cn` / 深交所 `szse.cn`：公告、交易监管。

## 二、权威财经媒体（国内实时）
- 财联社 `cls.cn`：盘中快讯、电报。
- 证券时报 `stcn.com` / 中国证券报 `cs.com.cn` / 上海证券报 `cnstock.com`。
- 每日经济新闻 `nbd.com.cn`。
- 第一财经 `yicai.com`。
- 华尔街见闻 `wallstreetcn.com`。
- 新浪财经 `finance.sina.com.cn`、腾讯财经、网易财经。
- 同花顺 `10jqka.com.cn`、雪球 `xueqiu.com`。
- 巨潮资讯 `cninfo.com.cn`：上市公司公告一手。

## 三、基金公司官网/基金平台
- 天天基金网 `fund.eastmoney.com`、蛋卷基金 `danjuanfunds.com`。
- 头部基金官网：华夏、易方达、南方、嘉实、富国、汇添富、广发、招商、博时、鹏华、工银瑞信、天弘、兴全、景顺长城、交银施罗德、中欧、银华、华安、国泰、建信。
- 用途：基金经理观点、季报/持仓变化、规模申赎，判断机构行为。

## 四、指数/行情/资金
- 中证指数 `csindex.com.cn`：指数编制与样本调整。
- 沪深港通/北向资金：交易所公开数据 + 东财/同花顺资金流。
- 期指/期权：中金所 `cffex.com.cn`。
- 大宗商品：上期所/大商所/郑商所 + LME/COMEX。

## 五、海外与跨市场
- 美联储 `federalreserve.gov`、美国财政部、BEA、BLS。
- IMF `imf.org`、世界银行 `worldbank.org`。
- Reuters、Yahoo Finance、CNBC、Investing.com、TradingEconomics、FRED。
- 地缘/军事：路透、BBC、新华社、半岛电视台。
- 海外中概/港股：港交所 `hkex.com.hk`、富途/老虎资讯。

## 六、使用规则
- 同一结论至少 2 个独立来源交叉，政策/数据以官方源为准。
- 来源可信度分层（2026-08-27 新增）：官方公告/交易所/监管 > 券商研报 > 权威媒体 > 基金/ETF 营销 > 股吧论坛；低位来源只作佐证，不单独采信；预测错的来源下调权重。
- 搜索前先记台账：`site / query / count / status`。
- 拿不到一手页，退到权威站点标题+摘要，不再无限重试同一通道。


## 2026-08-28 实测回退
- 东财 `opencli eastmoney quote/index-board` 直连 `push2.eastmoney.com` 失败（empty reply），暂不可用；`eastmoney kuaixun` 正常。
- 新浪行情 `hq.sinajs.cn`（需 Referer `https://finance.sina.com.cn/`）与 `money.finance.sina.com.cn` K线接口当日可用，作为实时行情/5分钟K线/日线的正式回退源。
- 外盘黄金/美股源仍缺（Yahoo/Reuters/BBC 浏览器桥或地区限制不可用），待补 COMEX 金价、美元指数、美债实际利率。
