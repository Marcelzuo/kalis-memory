# 玛门 · AI 产业与资本开支素材

> 采集日期：2026-08-25 · 范围：四大云厂 capex、订单、中美 AI 投入、代表性多空方
> 来源：UBS、Goldman、Morgan Stanley、Bloomberg/Reuters 等权威口径；本页仅存素材。

## 1. 美国 AI capex（核心多空之争）

| 口径 | 数据 | 结论方向 |
|:--|:--|:--|
| 四大云 2026 capex | 约 $725B，同比 +77% | 支出仍在加速 |
| UBS 2026–2028 累计 | 约 $4.1T | 高强度投入周期 |
| Goldman 2025–2030 累计 | 约 $5.3T | 长周期投入 |
| UBS 关键比值 | 2026 四大厂 capex = 云收入 102%，首次支出超过收入 | 看空论据：难持续 |
| Azure 积压 | 约 $80B | 看多论据：订单尚足 |
| Google Cloud backlog | >$514B | 看多论据：需求真实 |

## 2. 看空方代表（机构/个人）

- Michael Burry：买 $1.1B NVDA + PLTR 看跌期权。
- Elliott Management：称市场处于 “Bubble Land”。
- 其他：Paul Tudor Jones、Howard Marks、Jim Covello。
- 巴菲特指标 227%；Berkshire 现金 $400B。

## 3. 看多方代表（机构）

- Goldman、Morgan Stanley、JPMorgan、Powell 观点：AI 有真实盈利支撑。
- 关键估值论点：AI 股平均 P/E 约 35，远低于 2000 年互联网泡沫水平。

## 4. 学术证据（AI 生产率）

- Noy & Zhang, Science 2023：生成式 AI 提升生产率（被引 3826）。
- Cui et al., Management Science 2026：再证 AI 生产率收益。
- Acemoglu：宏观层面 AI 对 TFP 拉动仅 0.5–1%。

## 5. 中国 AI 投入（2026 Q2）

| 指标 | 数据 |
|:--|:--|
| 阿里+腾讯+百度 capex 合计 | 1318 亿元，同比 2.1 倍 |
| 阿里 | +75% |
| 腾讯 | +176% |
| 百度 | 约 3 倍，但营收连降 5 季 |
| DeepSeek V4 | 转向华为昇腾 |
