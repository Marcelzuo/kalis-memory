# 珞妤 · 学习

| 文件 | 内容 |
|:--|:--|
| `plan.md` | 初中全科学习方案 V2 |
| `math.md` | 数学错题铁律 |
| `english/novels.md` | 三本小说项目总纲 |
| `english/sop.md` | 小说双版本创作 SOP |
