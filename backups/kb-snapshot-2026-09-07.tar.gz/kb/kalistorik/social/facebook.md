# Facebook 发帖记录 · KALIS TORIK

> 每次发帖后即时更新

## 规则速查

| 项 | 值 |
|:--|:--|
| Hashtag 位置 | 第一条评论 |
| 标签数 | ≤7 |
| 格式 | 工厂日常实拍，不做品牌海报 |

## 发帖 SUMMARY

| 编号 | 日期 | 主题 | 状态 |
|:--|:--|:--|:--|
| FB #1 | 06-28 | 装柜前电话 | ✅ |
| FB #2 | 06-30 | 真实成本 | ✅ |
| FB #3 | 07-02 | sourcing 系列 Part 3 | ✅ |
| FB #4 | 07-06 | 展厅 vs 集装箱 | ✅ |
| FB #5 | 07-08 | 验货细节 | ✅ |
| FB #6 | 07-10 | 沉默证据 | ✅ |
| FB #7 | 07-13 | 工厂真实一面 | ✅ |
| FB #8 | 07-15 | 样品与订单差距 | ✅ |
| FB #9 | 07-21 | 暗箱操作 | ✅ |
| FB #10 | 07-23 | 开箱验货 | ✅ |
| FB #11 | 07-29 | 海运费 3x | ✅ |
| FB #12 | 07-30 | 清关翻车 | ✅ |
| FB #13 | 08-18 | 远程 QC | ✅ |
| FB #14 | 08-20 | 到港后第一步：unpaid balance | ✅ |
| FB #15 | 08-25 | 付款条款与尾款释放 | ✅ |
| FB #16 | 08-27 | 18 CBM / FCL vs LCL 决策 | ✅ 已发 |
| FB #17 | 09-01 | 海运货物保险·LCL 破损索赔（承接 LI #20） | ✅ 已发（v3） |

---


### FB #1 · 2026-06-28（4天前）

**正文：**
```
That call we make before the container leaves. 🪑
Mid-production QC. Before the container ships. Before the bill lands wrong.
We're on the ground in China. So you sleep at night in Europe.
→ kalistorik.com
```

**Hashtag（正文内）：**
```
#furnituresourcing #chinafactory #qualitycontrol #kalistorik
```

**配图：** —（纯文字帖）
**链接：** kalistorik.com
**互动：** 0 赞 · 0 评论 · 0 分享

---

### FB #2 · 2026-06-30（2天前）

**正文：**
```
Let's talk about the real cost of sourcing furniture from China.

Most independent retailers simplify it down to one simple formula: factory price + shipping = full cost.

The reality is far more layered. Every furniture order carries hidden expenses most buyers overlook:

✅ Core factory production costs: raw manufacturing, labour and factory overheads from pre-vetted reliable manufacturers
✅ Premium materials & finishing: fabrics, metal hardware and protective packaging — this is where huge gaps in product quality and durability show up
✅ End-to-end logistics: container loading, port fees, customs paperwork and final local last-mile delivery
✅ Mandatory pre-shipment quality control: thorough on-site inspection before your goods leave China, to avoid costly defective stock issues

The biggest hidden profit drain? Multiple middlemen stacked between you and the factory. Each extra layer adds its own markup, eating into your retail margin piece by piece.

Streamline the supply chain and cut out those unnecessary intermediaries, and your profit potential expands drastically. We've seen identical pieces from the exact same factory land at vastly different landed costs for retailers who source direct vs buying through third-party traders.

We've navigated European furniture supply chains for 20 years. We vet every factory, track every hidden expense in the process, and run strict QC checks before your shipment departs.

No hard sales pitch — just unfiltered industry insight we wish every furniture retailer had access to.
Wondering how streamlining your sourcing could boost your bottom line?
```

**Hashtag（正文末尾）：**
```
#FurnitureSourcing #FurnitureSupplyChain #IndependentRetail #ChinaSourcing #ProcurementTips #FurnitureBusiness #RetailMargin #SourcingPartner #EuropeanFurnitureRetail #HomeDecorWholesale #InteriorShopOwner
```

**配图：** —（纯文字帖）
**互动：** 1 赞 · 0 评论 · 0 分享

---

### FB #3 · 2026-07-02（今天）

**正文：**
```
Part 3 of our furniture sourcing series 🪑

Two posts ago we broke down the full hidden landed cost of sourcing furniture from China.
Last post we walked through our mandatory pre-container QC call before shipments head to Europe.
Both stories come from the exact same buyer's very first order with us.

Here's the truth: Neither transparent cost breakdown nor strict pre-ship QC alone can guarantee a smooth overseas order. You need both safeguards working together.

Now let's open the floor for discussion:
What's the most unexpected, eye-opening part of your first overseas furniture order? Share your story 👇
```

**Hashtag（第一条评论）：**
```
#FurnitureSourcing #EuropeanFurnitureRetail #SourcingPartner #FurnitureSupplyChain #IndependentRetail #ChinaSourcing #FurnitureBusiness
```

**配图：** `1_upscaled.webp`（1200×650，工厂上漆车间）
**互动：** 1 赞 · 0 评论 · 0 分享（发帖后即时）

---

## LinkedIn 个人 (Max Zuo / kalistorik)

### FB #4 · 2026-07-06

**正文：**
```
Between showroom displays and shipping containers, this is how your furniture order really looks.
No touch-ups, no catalog lighting. Just the factory production floor, and an expert who knows exactly what to inspect.
```

**Hashtag（第一条评论）：**
```
#FurnitureSourcing #ChinaSourcing #BehindTheProduct #FurnitureSupplyChain #RetailFurniture #FurnitureManufacturer
```

**配图：** `fb4.webp`（1200×661，工厂车间实拍·木材加工）
**互动：** —（刚发）

---
### FB #5 · 2026-07-08（✅ 已发）

**主题：** 验货时最容易漏掉的细节
**形式：** 短文案 + 引发讨论问题，工厂实拍风。
**Hashtag 位置：** 第一条评论。

**正文：**
```
During a recent pre-shipment inspection, our QC team spotted a subtle flaw most buyers would overlook:

Two dining chair frames from the same batch, identical specs — uneven leg lengths.

Invisible to the naked eye. Won't show up in packaging photos. Only becomes obvious when the chair wobbles on a customer's uneven floor.

This is the work that never makes it into a glossy catalog.

We find it because we measure. We measure because we've seen what minor dimensional deviations cost when goods land in a returned-goods warehouse.

Quick question for anyone sourcing furniture from overseas:
What subtle detail slipped past your last inspection, only to be flagged by your customers? 👇
```

**Hashtag（第一条评论）：**
```
#FurnitureSourcing #PreShipmentInspection #FurnitureQuality #ChinaSourcing #IndependentQC #FurnitureBusiness #EuropeanRetail
```

**配图：** `~/Desktop/fb2.jpeg`（工厂车间实拍，16:9）

**互动：** —（待发）

---

### FB #6 · 2026-07-10（✅ 已发 · 互动提问）

**主题：** 沉默证据系列 — 细节图 + 开放式提问
**格式：** 1 张图 + 1 行字，Hashtag 放第一条评论（≤5 个），无外链
**算法策略：** 原生内容优先 · 评论深度 > 点赞 · 不挂外链

**正文：**
```
What detail tells you a piece was made right? 👇
```

**第一条评论：**
```
#FurnitureCraftsmanship #QualityMatters
```

**配图：** 免版权实木家具细节图（木纹/接缝/手工痕迹）— 待玛门提供

**互动：** —（待发）

---

### FB #7 · 2026-07-13（✅ 已发）

**主题：** 与 IG #8 联动 — 工厂真实一面
**格式：** 短图文 + 讨论提问，Hashtag 放第一条评论

**正文：**
```
This is where your furniture actually starts. Not the showroom. Not the catalog. 

What's one thing you wish you knew about your supply chain before placing your first order? 👇
```

**第一条评论：**
```
#FurnitureSourcing #BehindTheScenes #FactoryFloor #ChinaManufacturing #SupplyChainTruth
```

**配图：** 工厂实拍（原图4 或 5）
**互动：** —（待数据）

---

### FB #8 · 2026-07-15（✅ 已发）

**主题：** 与 LI #9 / IG #9 联动 — 样品与订单的差距
**格式：** 短图文 + 讨论提问，Hashtag 放第一条评论

**正文：**
```
Your sample looked perfect, right?
You paid the deposit, waited six weeks, then the container lands…
And the mass-produced items don't match at all.
This isn't a scam — just a common sourcing headache most retailers discover too late.
What's the biggest sample/bulk quality mismatch you've dealt with? Drop your story below 👇
```

**第一条评论：**
```
#B2BFurniture #EuropeanFurnitureBuyers #SourcingTips
```

**配图：** 老板提供
**互动：** —（待数据）

---

### FB #9 · 2026-07-21（✅ 已发 · Reel）

**主题：** 与 LI #?（3 hidden production risks）联动 — 工厂暗箱操作可视化
**格式：** Reel（Title + Caption 双层）+ 9 标签

**Title：**
```
Hidden factory tricks furniture importers never see: fabric swaps & delayed production slots
```

**Caption：**
```
I covered the 3 hidden production risks over on LinkedIn. This is the harsh reality inside factories:
You transfer the deposit Monday, and by Wednesday your production slot gets bumped for three rush orders.
Materials stated on your PO? Just near-matching substitute fabrics.
QC documents? Signed before inspectors even check the goods.
I've seen this repeat year after year. Straightforward question for all furniture importers: How do you spot these hidden issues when you're 6,000 miles away from the workshop? Share your inspection methods below.
```

**Hashtags（标签框）：**
```
#FurnitureSourcing #EuropeanFurnitureBuyers #FabricForFurniture #SupplyChainRisk #QualityControl #ChinaManufacturing #ImportTips #B2BFurniture #KALISTORIK
```

**视频：** `~/Desktop/KALIS_TORIK_FB_Reel_0721.mp4` — 1080×1920、20.2s、8 图 Ken Burns + 工业配乐 + 尾卡 logo

**新规则落地：**
- FB Page 全部用 Reels（不用静态图）
- Title 20-40 词痛点前置
- Hashtags 8-10 个三层结构放标签框
- 自动字幕开启

---

### FB #10 · 2026-07-23（周四）

**Title：**
A perfect carton is a lie — until you open the drawers, test the hinges, and hold it next to the sample

**正文：**
```
The carton looks intact. The factory confirms everything passed.
But that isn't inspection — that's blind trust.
Genuine quality inspection works like this:
Unpack the carton. Pull out every drawer. Open all doors.
Check hinges, slide runners, level legs and inner corners — the hidden details no one bothers to photograph.
Place the unit side-by-side with your approved sample, under identical lighting.
Found a dent or defect? Take photos, and make sure the carton number is clearly visible.
No photos = no evidence. No evidence = no valid claim.
This is our standard process for every shipment we oversee.
A question for all furniture importers: What's the first thing your team checks when the container arrives? 👇
```

**标签：** `#FurnitureImport #QualityControl #FurnitureSourcing #ImportTips #FurnitureQC #KALISTORIK`
**视频：** `~/Desktop/fb10_cinema_reel.mp4` — 1080×1920、33.9s、Minimax image-01 素描电影风 + 底部字幕 + 纪录片配乐
**关联：** LI #11 验货实操的视觉姊妹篇，前 3 秒开箱割胶带
**互动：** —（待 48h 后复查）

---

### FB #11 · 2026-07-29（✅ 已发 · Reel）

**主题：** 与 LI #13（昨天 7/28）联动 — 海运费 3x 视觉姊妹篇，可视化双轨市场
**格式：** Reel 1080×1920 + Title + Caption + 8 个三层 hashtag 框
**视频：** `~/Desktop/fb_shipping_freight_tripled.mp4`（29.4s）

**Title：**
```
Freight rates tripled since June. Same container. Two completely different bills.
```

**Caption：**
```
Talked to a furniture importer in Rotterdam last week.

His last three containers: identical 40HQ, identical origin, identical week of departure.
His invoice said one number. The guy he sat next to at a trade fair paid nearly three times as much for the same box.

That's not bad luck. That's two freight markets running at the same time.

Big buyers locked contracts back when rates were normal. Smaller buyers are buying spot, week by week, into a market the carriers are quietly tightening.

You can see it on the sailing schedules — vessels leaving with space still on board, again and again. The carriers would rather sail half-empty than cut a dollar off the rate.

Not their fault, honestly. It's a disciplined playbook. It just happens to punish the people with the smallest orders the most.

If you're a small or mid importer and your freight bill has been creeping up this year, you're not imagining it. And it's not because of the headlines.

A question for anyone moving furniture out of Asia right now:
What's the gap between your contract rate and the spot rate you've been quoted lately? Drop the lane, drop the rough number — curious how wide this thing has gotten 👇
```

**Hashtags（标签框 · 三层）：**
```
#FurnitureImport #ShippingCrisis #ContainerRates #FreightMarket #SupplyChainRisk #EuropeanFurniture #B2BImport #KALISTORIK
```

**关联：** LI #13（昨天）的视觉姊妹篇 — LI 走深度分析（5 条具体行动建议），FB 走讨论风（抛问题引进口商晒运价差距）。同一个论点，两种打开方式。
**CTA 风格：** 评论提问（"drop the lane, drop the rough number"）→ 不挂外链、不带具体单价承诺、不点名承运人/货代，遵守品牌红线
**7 项红线自检：** ✅ 全过（无价格承诺 / 无工厂名 / 无 CIF / 无具体数字承诺 / AI 句式 0 / 中文 0 / 私人电话 0；行业现状披露级描述保留：运价倍数来自 LI #13 已发版）

---

### FB #12 · 2026-07-30（✅ 已发 · Reel）

**主题：** 与 LI #14（到港清关 + 开箱验收）联动 — 进口商清关翻车讨论
**格式：** Reel（Title + Caption）+ 9 个三层 Hashtag 标签

**Title：**
```
Your container reached port — then one wrong HS code, a broken seal record, or mismatched paperwork turned arrival into an expensive wait
```

**Caption：**
```
The container reaches port. Everyone relaxes.

Then customs questions the HS code. The packing list doesn't match the commercial documents. The seal number wasn't checked properly. Days start passing, and the container still isn't moving.

Even release isn't the finish line. When the doors open, where do you sample — only the cartons at the front, or the front, middle and back? And when you find damage, can every photo be traced to a carton number?

I broke down the detailed arrival, customs and unpacking steps on LinkedIn. Here, I'm more interested in the story nobody puts in the shipment report.

Importers: what was your worst customs or arrival-day failure? Wrong classification, missing paperwork, seal trouble, damage buried at the back — what happened, and what did you change afterwards?
```

**Hashtags（标签框 · 三层）：**
```
#FurnitureImport #FurnitureSourcing #EuropeanFurnitureBuyers #CustomsClearance #ImportCompliance #QualityControl #SupplyChainRisk #ContainerShipping #KALISTORIK
```

**关联：** LI #14 系列第 8 篇的视觉姊妹篇；LinkedIn 给详细步骤，Facebook 用清关翻车问题引发进口商分享经历。

---

### FB #13 · 2026-08-18（✅ 已发 · Reel）

**主题：** 与 LI 最新回归帖第 2 点“buyers demand proof”联动 — 中小买家低成本远程 QC 实操
**格式：** Reel 1080×1920 + Title + Caption + 8 个三层 Hashtag 标签框
**视频：** `~/Desktop/fb_inspection_slideshow_20260818_v3.mp4`（24.1s、4 张验货实拍、无位移、ambient_electronic、尾帧 Logo）

**Title：**
```
Small importers can’t fly to China for every order. When factories send photos, how do you confirm this batch is truly yours? Here are practical, low-cost remote QC checks.
```

**Caption：**
```
If you only place a handful of orders per year, you lack the bargaining power of big-box retailers.
That’s why your QC needs to be simple, low-cost and repeatable — not just look good on paper.

Here is the workflow I would follow as a small importer:

1. Never take factory photos as solid proof.
Request three elements in every shot:
- Visible carton number in every photo
- Your PO / reference number marked on cartons
- Surrounding factory floor in frame, to rule out pre-prepared sample-only shots
2. Don’t release balance upon “production finished”.
Release payment only after “inspection passed”.
Structure every order: deposit → production completion → independent inspection report → balance payment.
If a factory refuses this setup, it tells you exactly where the risk lies.
3. Book a focused short inspection, not a full factory audit.
Small orders do not require a full-site audit.
You only need an on-site person to count cartons, open random units, cross-check against your approved sample, and document defects with carton numbers.
This cost is tiny compared to losses from one faulty rework order.
4. Define your claims remedy inside the PO, before any payment.
Agree on this written priority:
Replacement goods → cash refund → credit against future invoices.
Without pre-agreed remedies, disputes turn into endless email threads.
5. Cannot afford an inspector? Run a live video verification.
Ask the factory to walk the production line, zoom-in on joints & edges, and show carton labels.
If they keep the camera too tight or refuse to comply, treat it as a failed inspection.

Your goal is not to inspect every single item.
It is to make the factory believe you might inspect something.

What low-cost QC step has saved you from costly issues? Share below.
```

**Hashtags（标签框 · 三层）：**
```
#FurnitureImport #FurnitureSourcing #QualityControl #FurnitureQC #EuropeanFurnitureBuyers #SupplyChainRisk #B2BSourcing #KALISTORIK
```

**关联：** LI 最新回归帖《I stepped away from LinkedIn for two weeks》第 2 点“tangible proof over empty promises”的视觉姊妹篇；从“买家要证据”落到小买家可执行的远程 QC 动作，不断档。
**红线自检：** ✅ 全过（无具体产品数字 / 无价格承诺 / 无工厂名 / 无 CIF / 无外链 / AI 句式 0 / 中文 0）

### FB #14 · ✅ 已发 · 2026-08-20（周二）

**主题：** 与 LI #16（昨天 8/19）联动 — 烂货到港后中小买家第一步该怎么办（视觉姊妹篇，6 步压缩为 3 步）
**格式：** Reel 1080×1920 + Title + Caption + 9 个三层 Hashtag 标签框
**视频：** 已发布（Reel 1080×1920）

**Title：**
```
Your container just arrived. You cut the seal, open the first carton, and the goods are wrong. Before you do anything else, remember this: your unpaid balance is your only leverage.
```

**Caption：**
```
The container arrived. The seal is broken. The goods are wrong.

If this is you right now, calm down. Here is what a small importer should actually do in the first 48 hours — a tighter version of the six-step playbook I published on LinkedIn yesterday.

1. Do not release the balance.
If the final payment is still unpaid, leave it unpaid. The moment funds leave your account, your bargaining position collapses. A supplier offering you a discount on the next order is not real compensation. Decline it.

2. Film the full unboxing, end to end.
Every carton. Every carton number visible. Every defect captured next to the carton number. Buyers lose claims almost always because the evidence is weak, not because the case is wrong.

3. Triage the goods into three buckets.
- Repairable locally
- Resellable at a discount
- Needs a formal claim against the supplier
Then push for the right remedy: local rework, replacement, or a partial refund. Returning goods to Asia rarely makes commercial sense — freight, duties and reshipping often exceed the value of the loss.

The truth is: you will never eliminate every bad batch. But paying the balance before the goods are verified is the single fastest way to turn a recoverable problem into a total loss.

Importers: what is the first move you make when the container arrives and the goods are wrong? Drop your real-world playbook below.
```

**Hashtags（标签框 · 三层）：**
```
#FurnitureImport #FurnitureSourcing #QualityControl #FurnitureQC #EuropeanFurnitureBuyers #SupplyChainRisk #B2BSourcing #ImportTips #KALISTORIK
```

**关联：** LI #16《烂货到港后的实操六步》的视觉姊妹篇；LinkedIn 给完整六步深度攻略，Facebook 压缩成"前 48 小时"3 步卡顿版，信息流停留优先。承接 FB #13 远程 QC 叙事：发货前没拦住 → 货到港后第一步该做什么。
**红线自检：** ✅ 全过（无具体价格 / 无工厂名 / 无 CIF / 无产品数字 / 无外链 / AI 句式 0 / 中文 0；尾款/折扣/修补/折价/索赔均为通用进口操作描述，无任何工厂或客户具名）
**互动：** 2 赞 · 1 评论（作者 hashtag）

---

### FB #15 · ✅ 已发 · 2026-08-25（周二）

**类型：** Reel 1080×1920 · 承接 LI #18
**主题：** 付款条款与尾款释放——供应商三种"标准条款"都在让你盲付尾款
**视频：** `/Users/zuo/Desktop/fb15_reel_20260825.mp4`（33.1s，电影级去饱和 + Didot 字幕，配乐 ambient_electronic）

**Title：**
```
You send 70% of payment before you even open one carton.
That's not a payment term. That's a donation.

3 dangerous contract clauses to remove.
3 protective clauses to keep for furniture importers.
```

**Caption：**
```
The costliest part of your furniture sourcing contract is rarely the unit price.
It's the payment term that lets suppliers collect your balance before you check the goods.

Watch out for these 3 common supplier traps hidden under "standard terms":

🔹 30/70 against B/L copy
B/L is issued once the container is sealed. You pay 70% weeks before you can inspect any goods — completely blind.

🔹 Net 7 against shipping document copies
Payment is due before customs clearance, before unboxing, before quality checks even happen.

🔹 Final balance on "successful loading"
"Successful" is defined by the factory. No third-party check, no safety gate for buyers.

✅ Swap them for these 3 importer-friendly payment triggers:

1️⃣ Independent third-party inspection PASS before releasing balance.
Not factory QC. Only a buyer-commissioned report unlocks payment.

2️⃣ Tiered remedy rules with hard deadlines.
Rework, replacement, credit note — all with fixed dates. "Soon" means nothing in a contract.

3️⃣ Origin-based pre-shipment reject & rework clause.
Set your defect tolerance. Reject bad batches before they leave the port.

Expect push-back.
Suppliers will claim these terms are odd, slow for production, or bad for your partnership.
Their push-back tells you everything.

If basic risk-control breaks your business relationship, your partnership was never built on reliable output.
It was built on your money.

Full detailed analysis on my LinkedIn post yesterday.
This Reel is your quick one-page reference you can show your supplier tomorrow.

Which clause does your factory push against the most?
Drop your exact contract wording in comments.
```

**Hashtags（标签框 · 三层）：**
```
#FurnitureSourcing #FurnitureImportEU #B2BSourcing #EuropeanFurnitureBuyers #QualityControl #ChinaManufacturing #SupplyChainRisk #ImportTips #KALISTORIK
```

**关联：** LI #18《付款条款与尾款释放》视觉姊妹篇；LI 给完整合同逻辑，FB 压缩成三陷阱 vs 三锁死条款，信息流停留优先。
**红线自检：** ✅ 全过（无价格承诺 / 无工厂名 / 无客户名 / 无订单金额 / 无 CIF / 无外链 / AI 句式 0 / 中文 0；70%、Net 7、30/70 为付款条款行业术语）
**互动：** 1 赞 · 1 评论（作者 hashtag）

---

### FB #16 · ✅ 已发 · 2026-08-27（周四）

**类型：** Reel 1080×1920 · 承接 LI #19
**主题：** 18 CBM 风险区——第一票家具进口最坑的体积 / FCL vs LCL 三档决策
**视频：** `/Users/zuo/Desktop/fb16_reel_20260827.mp4`（20s · 1080×1920 · 30fps · H.264）
**作者：** 老板终稿

**Title：**
```
Your first furniture import hits 18 CBM.
Not enough to fill a 20ft container, too much for cheap LCL.
This is the volume where importers lose their margin.
```

**Caption：**
```
Your first furniture import order hits 18 CBM.
This is the riskiest volume bracket for furniture buyers.

Too small for a full 20ft FCL — you end up paying for unused dead space.
Too big for LCL, triggering heavy surcharges. Worse, your goods share a container with third‑party cargo you cannot control.

Most new importers decide by gut instinct:
Shocked by FCL freight rates → they go LCL.
Or they book FCL anyway and end up paying near‑airfreight costs.

Base your call on volume, not feelings:

• Below 15 CBM → LCL makes practical sense.
You pay per cubic meter. Any wasted carton space equals lost profit.

• 15‑25 CBM → the tricky grey zone.
Consolidate orders or add fast‑moving SKUs to push volume over 25 CBM. FCL usually becomes the better option.

• Over 25 CBM → FCL delivers lower cost per CBM in most cases.
You also retain full container control.

Volume is only one piece of the puzzle.
Watch for 3 hidden cost leaks before confirming any freight quote:

1. Request landed‑to‑warehouse cost, not merely FOB.
Port charges, document fees, inspection costs and demurrage will pop up after cargo arrives.
2. Avoid shipping high‑value furniture via LCL.
Damage in shared containers happens frequently. Forwarders seldom accept liability. Choose FCL or arrange cargo insurance before shipment.
3. Avoid placing orders within 6 weeks ahead of Chinese New Year.
Factory closures plus post‑holiday container shortages can turn a January order into a March delivery.

A freight quote alone never paints the full picture.
Margins get destroyed by hidden landed costs, shared‑container damage and poor timing.

👇 Comment: Was your last order above or below 18 CBM?
DM me to grab the one‑page FCL / LCL decision worksheet.
```

**Hashtags（标签框 · 三层）：**
```
#FurnitureSourcing #FurnitureImportEU #B2BSourcing #EuropeanFurnitureBuyers #Logistics #FreightForwarding #Shipping #SupplyChainRisk #KALISTORIK
```

**关联：** LI #19《18 CBM 风险区》视觉姊妹篇；LI 给完整体积决策框架，FB 压缩成三档 + 三条成本泄漏，信息流停留优先。承接 FB #15 付款条款叙事：条款锁死后，下一刀在运费结构。
**红线自检：** ✅ 全过（无价格承诺 / 无工厂名 / 无客户名 / 无订单金额 / 无 CIF / 无外链 / AI 句式 0 / 中文 0；15/18/25 CBM 与 6 周为物流门槛术语，非产品尺寸数字）

**视频制作参数（玛门）：**
- 尺寸：1080×1920 竖版 · H.264 · 30fps · 30–35s
- 风格：延续 FB #15 电影级去饱和 + Didot 字幕；冷灰/集装箱蓝调
- 配乐：无版权纯音乐 ambient_electronic 或 industrial_cinematic，无人声，开启自动字幕
- 素材：优先真实集装箱/仓库/装柜素材；如生成静帧需电影海报质感，不得出现外国面孔/品牌
- 分镜：① 黑场 Title「18 CBM. The riskiest volume.」② 20ft 集装箱 vs LCL 拼箱，18 CBM 卡中间 ③ 三档决策卡：<15 LCL / 15–25 灰区红标 / >25 FCL ④ 三条成本泄漏卡 ⑤ 字幕三连：FOB≠landed · 高值走 FCL · CNY 前 6 周别下单 ⑥ CTA 黑底金线：DM for FCL/LCL worksheet + KALIS TORIK
- 交付：`/Users/zuo/Desktop/fb16_reel_20260827.mp4`

---

### FB #17 · ✅ 已发（v3）· 2026-09-01（周二）

**类型：** Reel 1080×1920 · 承接 LI #20
**视频：** `/Users/zuo/Desktop/fb17_reel_20260901_v3.mp4`（44.0s · 1080×1920 · 30fps · H.264）· v3 重出（品牌原图 Logo + 6 张不同背景）；v1 `/Users/zuo/Desktop/fb17_reel_20260901.mp4`（31.5s）、v2 已废弃
**主题：** 海运货物保险——LCL 破损到底谁来赔 / 何时买、买什么险、留什么单证
**作者：** 路西法初稿（任务链 fb-20260901-17）

**Title：**
```
Nine days on the open ocean before a port crane touches it.
Waves, heat and rough handling in shared holds take a silent toll.
Yet most furniture shipments sail uninsured.
Marine cargo insurance exists to cover exactly that voyage.
```

**Caption：**
```
Your LCL container lands and three cartons arrive crushed.
The carrier says "cargo received in good order".
The forwarder passes the buck.
The factory hides behind the bill of lading.
Every stakeholder has an excuse — nobody covers the loss.

Nine importers out of ten skip marine cargo insurance thinking it is optional.
It is not. It is the only reliable point of contact when LCL damage happens.
Shared containers see scratches, crushed cartons, water ingress and condensation mould all the time — and forwarders almost never accept liability.

Three rules decide whether your claim gets paid:

1. Buy insurance before container loading, never after.
A policy taken out after sealing is wide open to "inward condition" arguments. Your claim is contested from the first line.

2. Choose All Risks (Institute Cargo Clauses A).
Budget FPA or WA clauses reject the exact furniture damage you are likely to face. If your policy cannot cover a crushed carton, it is not protecting you at all.

3. Insure for more than the invoice value.
A 10% uplift covers your buying costs; the industry-standard 110% insured amount protects your expected profit too. Insure at 110% — it exists for practical reasons.

When damage does happen, four documents win your claim:
• Photos of the container seal number — at factory departure and destination arrival
• Time-stamped, carton-by-carton unboxing footage
• Surveyor's report obtained within days of container opening, before the carrier has time to argue
• Your original commercial invoice, packing list and clean bill of lading, kept on file

If you ship LCL more than once a year, skip the insurance and every crushed carton is a written-off sale.

DM me for the one-page marine cargo checklist — the exact clauses and photographic evidence that separate an approved claim from a declined one.
```

**Hashtags（标签框 · 三层）：**
```
#MarineCargoInsurance #FurnitureImport #LCLShipping #CargoClaims #FurnitureSourcing #EuropeanFurnitureBuyers #B2BSourcing #ImportTips #KALISTORIK
```

**关联：** LI #20《海运货物保险——LCL 破损到底谁来赔》视觉姊妹篇；LI 给完整硬规则与单证逻辑，FB 压缩成三条保险铁律 + 四类索赔单证，信息流停留优先。承接 FB #16 成本泄漏叙事：运费结构锁死后，下一刀在保险与索赔单证。
**红线自检：** ✅ 全过（无价格 / 无工厂名 / 无客户名 / 无订单金额 / 无 CIF / 无外链 / AI 句式 0 / 中文 0；10% 与 110% 为保险行业术语，非产品尺寸数字）

**视频制作参数（米迦勒终审 · 玛门执行）：**
- 尺寸：1080×1920 竖版 · H.264 · 30fps · 30–33s
- 风格：唯美电影大片，冷暖双调——开场冷蓝海面/货轮，高潮金色黄昏港口；Didot 或同气质衬线字幕；无破损/无开箱/无工厂画面
- 配乐：ambient_electronic 或 sad_piano_heartbreaking，无人声，开启自动字幕
- 素材：优先高清无水印实拍（Unsplash/Pexels 货轮航拍、海面、黄昏港口）；拿不到高清则 DashScope 生成同风格电影静帧；竖版优先，长边 ≥1440px，无外国面孔/品牌
- ⚠️ 防抖铁律：本片禁用 zoompan/Ken Burns 缩放运镜；画面静态 + crossfade 0.4–0.5s，文字卡固定位置淡入；如需动效只做整图匀速位移，禁止缩放与位移叠加，避免像素抖动
- 分镜：① 黑场冷蓝 Title（路西法终稿，海上语境）② 货轮海面航拍 ③ 三条保险铁律白底卡 ④ 四类索赔单证浅色卡 ⑤ 黄昏金色海面/港口唯美高潮 ⑥ 黑底金线 CTA：DM for one-page marine cargo checklist + KALIS TORIK
- **v2 修订（09-01 老板复审，已重出）**：移除全部纯色底文字卡，每帧以实拍图作背景、文字叠留白（天空/海面）+ 半透明深色渐变遮罩；停留拉长、crossfade 0.5s→1.0s；② 新增 Carrier/Forwarder/Factory blame 三句（逐字取自 Caption）。素材与配乐不变。
- **v3 修订（09-01 老板复审，已重出）**：① Logo 禁手绘，改品牌原图 `logo-kalis-torik-dark.svg`（Chrome headless 渲染透明 PNG，删菱形金标，金线 #C9A96E 顶部 + KALIS + TORIK 分层）粘贴 CTA 尾帧；② 6 帧用 6 张不同背景（货轮/集装箱/吊机/堆场，末帧由游艇改货轮），全部 Pexels 原图长边 ≥1440px。文字、配乐、防抖不变。


---

### FB #18 · 🎬 已出片待审 · 2026-09-03（周四）

**类型：** Reel 1080×1920 · 承接 LI #21（视觉姊妹篇）
**主题：** 交货窗口倒推——从卖货季往前算，Q4/圣诞旺季谁先守住窗口
**作者：** 路西法初稿 → 老板优化（任务链 fb-20260903-18）
**视频：** `/Users/zuo/Desktop/fb18_reel_20260903.mp4`（34.0s · 1080×1920 · 30fps · H.264 · 3.8MB · 全静态帧+crossfade 0.9s）

**正文（Title+Caption 合并 · 老板优化）：**
```
You get an ETA of early December — but your Christmas sales window can be over before the container even leaves the yard.

The fix: plan backward from your peak selling period, not forward from your order date. This is how you safeguard your holiday season.

Start from your selling season and work backwards milestone by milestone:
selling season ← final-mile delivery ← port clearance ← ocean transit ← vessel booking ← production lead time

A shipment is only as reliable as its weakest link. This quarter, the bottleneck is rarely your factory. It is the global peak shipping window. Every EU furniture importer competes for the same vessels, berths and container space. Those who secure space early gain the upper hand. Timing is your lowest-cost competitive advantage.

Three practical steps to mitigate risk right now:

1. Request a formal written production schedule, not just a preferred completion date. Attach inspection checkpoints to each milestone before releasing balance payments.
2. Confirm firm sailing dates with your freight forwarder. An ETA printed on a commercial invoice is an estimate. A confirmed sailing date is a commitment you can hold stakeholders accountable to.
3. Link your final payment to tangible loading proof: confirmed booking reference, container number, timestamped yard photos. Pay on evidence, not verbal promises.

Always build extra buffer into your timeline. Combined peak seasons in China and Europe create unavoidable delays. Any supplier promising rigid fixed dates is simply guessing.

Order now, and you only fight against time itself. Wait a few more weeks, and you compete against every other importer chasing Christmas stock.

DM me for my one-page countdown worksheet. Calculate your order cutoff backwards from your target selling date, lock accountable milestones, and get your containers shipped before the window closes. Straightforward, no fluff.
```

**Hashtags（标签框 · 三层）：**
```
#FurnitureSourcing #FurnitureImportEU #EuropeanFurnitureBuyers #B2BSourcing #Logistics #SupplyChain #ChinaManufacturing #HolidayRetail #KALISTORIK
```

**关联：** LI #21《交货窗口倒推——从卖货季往前算》视觉姊妹篇；LI 给完整倒推链条与三条硬动作，FB 压缩成「倒推链条可视化 + 3 moves + now vs wait 对比」，信息流停留优先。
**红线自检：** ✅ 全过
  - ✅ 无价格（无单价 / 报价区间 / 金额）
  - ✅ 无工厂名 / 客户名 / 订单数字
  - ✅ 无 CIF / FOB / 贸易条款出入
  - ✅ 无产品具体数字（weeks / ETA / peak / selling window 均为时间口径，非尺寸价格）
  - ✅ 无 AI 句式（短句、破折号、单句段、口语化直陈）
  - ✅ 全文英文，无中文
  - ✅ 无外链；Hashtag 9 个三层收于 #KALISTORIK

**视频制作参数（玛门执行 · 待出片）：**
- 尺寸：1080×1920 竖版 · H.264 · 30fps · 30–35s
- 风格：延续 FB #15/#17 电影级；冷灰/货轮/港区基调
- 配乐：无版权 ambient_electronic 或 industrial_cinematic，无人声，开启自动字幕
- 视觉母题（已定）：倒计时日历 + 竖版时间轴 + split-screen（⚠️ 非港口实拍卡轮播）
  - ① 倒计时日历快速翻页 →「Dec 25」钉在焦点的压迫开场
  - ② split-screen：左卖货季（shelf 卖空空位）vs 右生产端（车间/堆场），同步「backward」倒序
  - ③ 竖版倒推时间轴自上而下：selling season → final-mile → clearance → ocean → vessel booking → production lead time（逐格点亮）
  - ④ 3 moves 卡（书面排期 / sailing date / 装柜证据绑定尾款）
  - ⑤ 对比 frame：Order now vs wait a few weeks（窗口 vs 错过）
  - ⑥ CTA 黑底金线：#C9A96E · DM for one-page countdown worksheet + KALIS TORIK
- 防抖铁律：禁用 zoompan / Ken Burns 缩放运镜；静态 + crossfade 0.4–1.0s
- 交付占位：`/Users/zuo/Desktop/fb18_reel_20260903.mp4`
