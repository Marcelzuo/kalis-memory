# IG 发帖记录 · KALIS TORIK (@kalistorik)

> 每次发帖后即时更新 · 含 Feed + Story

## 规则速查

| 项 | 值 |
|:--|:--|
| Hashtag 位置 | 正文末尾 |
| 标签数 | ≤10 |
| Caption 长度 | ≤3 行 |
| 格式 | 网上采集真实工厂照片/视频，不用黑底排版 |

## 发帖 SUMMARY

| 编号 | 日期 | 主题/形式 | 状态 |
|:--|:--|:--|:--|
| IG #1 | 06-29 | 图片帖 | ✅ |
| IG #2 | 06-29 | Carousel | ✅ |
| IG #3 | 07-01 | Reel | ✅ |
| IG #4 | 07-03 | 图片帖 | ✅ |
| IG #5 | 07-06 | Carousel | ✅ |
| IG #6 | 07-08 | Carousel | ✅ |
| IG #7 | 07-10 | Carousel | ✅ |
| IG #8 | 07-13 | 工厂真实一面 | ✅ |
| IG #9 | 07-15 | 样品与订单差距 | ✅ |
| IG #10 | 07-25 | Reel | ✅ |
| IG #11 | 08-17 | Reel · 探 China / vacation | ✅ |
| IG #12 | 08-26 | Reel · unpaid balance（承接 LI #18） | ✅ |
| IG #13 | 09-07 | Reel · the quiet decisions behind a beautiful room（承接 LI #23） | ✅ 已发 |

---


### IG #1 · 图片帖（6/29 · 4天前）

**Caption：**
```
Furniture sourcing from China.
We check what factories won't tell you.
→ kalistorik.com
```

**Hashtag（正文内）：**
```
#furnituresourcing #chinafactory #qualitycontrol #kalistorik
```

**类型：** 图片帖
**链接：** `instagram.com/kalistorik/p/DaKVfiUD38q/`
**互动：** —（新号无数据）

---

### IG #2 · Carousel（6/29 · 3天前）

**Caption：**
```
The math behind China sourcing, in 5 slides.

63% of European retailers aren't doing it by accident — they're solving a margin problem.

Swipe through ➡️
```

**Hashtag（正文内）：**
```
#FurnitureSourcing #ChinaSourcing #RetailStrategy #IndependentRetail #FurnitureTrade #SourcingPartner #RetailMargin #FurnitureBusiness #kalistorik
```

**类型：** 5 页轮播（数据图表）
**链接：** `instagram.com/kalistorik/reel/DaPrexeBIZc/`
**互动：** —（新号无数据）

---

### IG #3 · Reel（7/1 · 1天前）

**Caption：**
```
Between the factory floor and your living room, the same chair usually changes hands 2–3 times.
Every transfer tacks on hidden margin that's never shown in your quote.
```

**Hashtag（正文内）：**
```
#FurnitureSourcing #ChinaManufacturing #SourcingTransparency #FurnitureTrade #SupplyChainTruth
```

**类型：** Reel
**链接：** `instagram.com/kalistorik/reel/DaF5tOEh5Yj/`
**互动：** —（新号无数据）

---

## 📋 规则速查

| 平台 | Hashtag 位置 | 标签数 |
|------|-------------|:--:|
| FB | 第一条评论（#3 起执行） | ≤7 |
| LI | 正文末尾 | ≤5 |
| IG | 正文末尾 | ≤10 |

---

> 更新：2026-07-02 · 米迦勒 · 三平台全量补齐

---

## IG Story

### Story #1 · 2026-07-02

**Caption：**
```
The most costly furniture imported from China
is the shipment you skip inspecting.
```

**配图：** 工厂车间 QC 检验实拍
**链接：** IG Story（24h 后消失）

---

> 更新：2026-07-02 · 首条 Story 已发布

---

### IG #4 · 图片帖（7/3）

**Caption：**
```
Your factory sent QC photos? Ours are taken by our own team.
```

**Hashtag（第一条评论）：**
```
#FurnitureSourcing #IndependentQC #ChinaSourcing #FurnitureRetail #SupplyChain #kalistorik
```

**配图：** `1.jpeg`（车间 QC 实拍）
**互动：** —（新号无数据）


---

### LI #4 · 2026-07-03

**发布时间：** 2026-07-03 BJT
**正文：**
```
Most sourcing problems don't come from bad factories.
They come from good factories taking orders they can't handle well.
[...]

The best results do not come from the largest factory or the cheapest price.
They come from picking a factory that fits your exact product type, order quantity and budget.

Price talks, quality checks and shipping are all secondary.
```

**Hashtag（第一条评论）：** `#FurnitureSourcing #ChinaManufacturing #SupplyChain #Procurement #FurnitureIndustry`
**互动：** —


### IG #5 · Carousel（7/6）

**Caption：**
```
Five places the cost of your next order quietly grows.
None of them are on the quote page.
Swipe through ➡️
```

**Hashtag（第一条评论）：**
```
#FurnitureSourcing #ChinaManufacturing #SourcingTransparency #FurnitureTrade #SupplyChainTruth #IndependentQC #FurnitureBusiness #PreShipmentInspection
```

**类型：** Carousel（COST LEAK 系列 · 第1期）
**配图：** 多图轮播，主题 "sample was A-grade wood, Monday's cut wasn't"
**互动：** —（发帖 6h）

---
### IG #6 · Carousel（7/8 · ✅ 定稿）

**Caption（≤3 行）：**
```
Behind every catalog photo is a factory floor that would never make the brochure.
```

**Hashtag（第一条评论）：**
```
#FurnitureSourcing #QualityControl #PreShipmentInspection #BehindTheScenes #ChinaManufacturing #B2BSourcing
```

**格式：** Carousel · 4 张

**视觉风格：** 暗调剧场 — Bodoni 72 · 木纹暗底 · 电影光柱 · 胶片颗粒 · 白色 Logo 贴图

**4 张内容：**

| 卡 | 第1行 | 第2行 | 第3行 |
|:--|------|------|------|
| 1 | THE DETAIL YOUR | CATALOG WON'T SHOW | — |
| 2 | EVERY FLAW. | EVERY REJECT. | EVERY MEASUREMENT |
| 3 | WHAT PASSES | EARNS ITS PLACE. | — |
| 4 | THIS IS THE CATALOG | WE KEEP. | — |

**排版规范：** 62px 统一字号 · 82px 行距 · 居中 · 光柱照亮对应行
**配图文件：** `~/Desktop/ig6_01.png` ~ `ig6_04.png`
**Logo 资产：** `~/.codex/assets/logo_kalis_white.png`

**互动：** —（待发）

---

### IG #7 · 2026-07-10（✅ 定稿 · Carousel）

**主题：** THE HANDS YOU DON'T SEE — 订单在你不知道的人手里传递
**格式：** Carousel 4 张 1080×1080，Caption ≤3 行，Hashtag 第一条评论
**视觉风格：** 黑白纪实风 — 高对比黑白，Helvetica Bold，红色强调竖线，胶片编号，右下角白色 Logo

**4 张内容：**

| 卡 | 文案 |
|:--:|------|
| 1 | YOUR ORDER DOES NOT LEAVE THE FACTORY LIKE THE CATALOG PHOTO |
| 2 | HANDS YOU NEVER MEET TOUCH IT AT EVERY STEP |
| 3 | THE GAP BETWEEN SAMPLE AND SHIPMENT IS FILLED BY PEOPLE WITH NO NAME |
| 4 | WE PUT OURS THERE INSTEAD — KALIS TORIK |

**Caption：**
```
What happens between the sample and the container.
```

**第一条评论：**
```
#FurnitureSourcing #BehindTheScenes #SupplyChainTruth #B2BSourcing #QualityControl
```

**配图：** `/Users/zuo/Desktop/ig7_01.png` ~ `ig7_04.png`（玛门生成中）

**互动：** —（待发）

---

### IG #8 · Carousel（7/13 · ✅ 已发）

**主题：** 反美学工厂背面 — 不展示厅，展示真实
**格式：** Carousel 4 张 1080×1350，Caption ≤3 行，Hashtag 第一条评论
**视觉风格：** 暗调剧场 — 去饱和高对比 + 强暗角 + 胶片颗粒 σ=6，白色 Helvetica Light，右下角白色 Logo

**4 张内容：**

| 卡 | 配图 | 文案 |
|:--:|:--|:--|
| 1 | `ig8_01.png` | YOUR FURNITURE DOESN'T START IN A SHOWROOM. |
| 2 | `ig8_02.png` | IT STARTS HERE. |
| 3 | `ig8_03.png` | WHERE HANDS WITH NO INSTAGRAM MAKE THINGS THAT END UP IN YOURS. |
| 4 | `ig8_04.png` | AND THIS IS WHAT COMES OUT THE OTHER SIDE. KALIS TORIK |

**Caption：**
```
Nobody posts this side. We do.
```

**第一条评论：**
```
#FurnitureSourcing #BehindTheScenes #FactoryFloor #ChinaManufacturing #SupplyChainTruth #RawAndReal #B2BSourcing #NotAShowroom #kalistorik
```

**互动：** —（待发）

---

### IG #8 · Carousel（7/13 · ✅ 已出图 · Warm Documentary V3）

**主题：** 反美学工厂背面 — 纪录片电影海报风
**格式：** Carousel 4 张 1080×1350，Caption ≤3 行，Hashtag 第一条评论
**视觉风格：** Warm Documentary — 保留原图100%色彩，极轻暖色调色，文字在底部渐变蒙层上，Helvetica Light 细体，右下角白色 Logo

**4 张内容：**

| 卡 | 配图 | 文案 |
|:--:|:--|:--|
| 1 | `ig8_v3_01.png` | YOUR FURNITURE DOESN'T START IN A SHOWROOM. |
| 2 | `ig8_v3_02.png` | IT STARTS HERE. |
| 3 | `ig8_v3_03.png` | WHERE HANDS WITH NO INSTAGRAM MAKE THINGS THAT END UP IN YOURS. |
| 4 | `ig8_v3_04.png` | AND THIS IS WHAT COMES OUT THE OTHER SIDE. KALIS TORIK |

**Caption：**
```
Nobody posts this side. We do.
```

**第一条评论：**
```
#FurnitureSourcing #BehindTheScenes #FactoryFloor #ChinaManufacturing #SupplyChainTruth #RawAndReal #B2BSourcing #NotAShowroom #kalistorik
```

**互动：** —（待发）

---

### IG #8 · Carousel（7/13 · ✅ 已出图 · 最终版）

**主题：** 反美学工厂背面 — 电影级真实感
**格式：** Carousel 4 张 1080×1350，Caption ≤3 行，Hashtag 第一条评论
**视觉风格：** 电影级轻调色（contrast+6%, 微暖）、底部渐变蒙层、Helvetica Light 白字、右下角白色 Logo

**4 张：**

| 卡 | 文件 | 文案 |
|:--:|:--|:--|
| 1 | `ig8_01.png` | YOUR FURNITURE DOESN'T START IN A SHOWROOM. |
| 2 | `ig8_02.png` | IT STARTS HERE. |
| 3 | `ig8_03.png` | WHERE HANDS WITH NO INSTAGRAM MAKE THINGS THAT END UP IN YOURS. |
| 4 | `ig8_04.png` | AND THIS IS WHAT COMES OUT THE OTHER SIDE. KALIS TORIK |

**Caption：** Nobody posts this side. We do.
**Hashtag：** #FurnitureSourcing #BehindTheScenes #FactoryFloor #ChinaManufacturing #SupplyChainTruth #RawAndReal #B2BSourcing #NotAShowroom #kalistorik
**互动：** —（待发）

---

### IG #9 · Carousel（7/15 · ✅ 已出图 · Cinematic Poster）

**主题：** 样品与订单的差距 — 电影海报系列
**格式：** Carousel 4 张 1080×1080，Caption ≤3 行，Hashtag 第一条评论
**视觉风格：** 唯美家具实拍背景 + 暗渐变遮罩 + Futura 大字排版 + 品牌金点缀

**4 张内容：**

| 卡 | 文件 | 大字 | 顶部标签 | 底部文字 |
|:--:|:--|:--|:--|:--|
| 1 | `IG9-1.png` | PERFECT | SAMPLE APPROVED | Flawless craftsmanship. You signed off. |
| 2 | `IG9-2.png` | WRONG | SIX WEEKS LATER | The container arrived. Nothing matched. |
| 3 | `IG9-3.png` | THIS | BETWEEN THE TWO | The gap. This is where we work. |
| 4 | `IG9-4.png` | KALIS / TORIK | CONCLUSION | We close the gap. Every time. |

**调色：** 卡1 暖琥珀 · 卡2 冷蓝暗调 · 卡3 中性过渡 · 卡4 品牌金棕

**Caption：**
```
Every order tells two stories.
We make sure they end the same way.
```

**第一条评论：**
```
#FurnitureSourcing #BehindTheScenes #FactoryFloor #ChinaManufacturing #SupplyChainTruth #B2BSourcing #kalistorik
```

**互动：** —（待发）

---

### IG #10 · Reel（7/25 · ✅ 已出片 · 待老板发布）

**主题：** 工厂 QC 真实画面 — 与 LI #10「hidden production risks」视觉姊妹篇
**格式：** Reel 1080×1080，12.5s，6 张工厂实拍 + Ken Burns + crossfade
**音乐：** industrial_cinematic.mp3

**Caption：**
```
Factory QC floor — finding defects management would rather you didn't see.

What production lines hide becomes public the moment a shipment fails.

We check so you don't have to. → kalistorik.com
```

**第一条评论：**
```
#FactoryQuality #QCCheck #MadeInChina #SupplyChain #ImportBusiness #FactoryAudit #ChinaManufacturing #QualityControl #SourcingAgent #kalistorik
```

**视频：** `~/Desktop/ig10_reel.mp4`（3.6MB）
**互动：** —（待发）

---

### IG #10 v2 · Reel（7/25 · ✅ 已发）

**主题：** EVERY ORDER. EVERY CHECK. — 沙发验货蒙太奇
**格式：** Reel 1080×1080，16s，6 段节拍同步剪辑 + crossfade
**音乐：** industrial_cinematic.mp3
**视觉：** 慢动作 0.6x + 暗调调色 + 白字叠加 + 右下角 Logo

**时间线：**
| 时间 | 画面 | 叠加文字 |
|------|------|----------|
| 0-2.5s | 沙发全景 → 缝线 | EVERY ORDER. → EVERY SEAM. |
| 2.5-5s | 坐垫 → 针脚 | EVERY CUSHION. → EVERY STITCH. |
| 5-7.5s | 框架检查 | EVERY FRAME. → BEFORE IT LEAVES. |
| 14-16s | 黑屏 | KALIS TORIK（品牌金） |

**Caption：**
```
Every order. Every seam. Every stitch.

Before it leaves the factory,
we check what you can't. → kalistorik.com
```

**第一条评论：**
```
#FurnitureQC #SofaInspection #QualityControl #ChinaManufacturing #SupplyChainTruth #BeforeItShips #B2BSourcing #FurnitureSourcing #PreShipmentInspection #kalistorik
```

**视频：** `~/Desktop/ig10_reel_v2.mp4`（6.3MB）
**构建脚本：** `~/Desktop/build_ig10_reel.sh`（可微调重跑）
**互动：** 0 粉 · 0 真实互动（冷启动）

---

### IG #11 · ✅ 已发 · 2026-08-17（周一）

**类型：** Reel · 探 China / vacation
**链接：** `https://www.instagram.com/kalistorik/reel/DcIckGtBkXs/`
**Caption（上线观测）：**
```
Take a break from work and explore the beauty of China.
```
**Hashtags / 完整 caption：** 待补（需进帖页抓取）
**互动（2026-08-30 采）：** 175 播放 · 164 触达 · 1 赞 · 0 评论/收藏/分享 · 0 主页访问 · 0 关注

---

### IG #12 · ✅ 已发 · 2026-08-26（周三）

**类型：** Reel · 承接 LI #18
**主题：** unpaid balance——先验货，再放尾款
**链接：** `https://www.instagram.com/kalistorik/reel/DcbGTcthSP7/`
**Caption（上线观测）：**
```
Your unpaid balance is your only leverage.
Inspect first. Release balance second.
Lock payment to inspection — not promises.
```
**Hashtags（作者第一条评论）：** `#FurnitureSourcing #FurnitureImportEU #QualityControl #B2BSourcing #EUFurnitureMarket #ChinaSourcing #FurnitureImport #KALISTORIK`
**互动（2026-08-30 采）：** 163 播放 · 159 触达 · 1 赞 · 0 评论/收藏/分享 · 0 主页访问 · 0 关注

---

## 2026-08-27 上线快照

| 指标 | 数值 |
|:--|:--:|
| 帖子 | 13 |
| 粉丝 | 0 |
| 关注 | 0 |
| 简介 | 20+ years. 100+ vetted factories. / Furniture sourcing partner China → EU / QC inspection · Factory audit · Door-to-port |

---

### IG #13 · ✅ 已发 · 2026-09-07（周一）

**类型：** Reel · 承接 LI #23
**主题：** 一个漂亮房间不会告诉你它背后的安静决策——从材料、排期、开料前检查到成品，最后收在品牌 Logo
**视频：** `/Users/zuo/Desktop/ig_weeklybrief_20260907.mp4`
**音乐：** `Ear0_30s_BGM_CC0.mp3`（耳聆网 CC0，国内素材；已附 license 文件）
**画面文案：**
```
A beautiful room never tells you the decisions behind it.
Before it enters this room, someone chose the material.
And someone locked the production timeline on paper — not on a promise.
And someone checked the material before the first cut.
We make the quiet decisions, so the room stays beautiful.
KALIS TORIK
```

**Caption：**
```
A beautiful room never tells you
who made the quiet decisions behind it.

That’s exactly what we do.
→ kalistorik.com
```

**第一条评论 Hashtags：**
```
#FurnitureSourcing #FurnitureImportEU #QualityControl #B2BSourcing #EUFurnitureMarket #ChinaSourcing #InteriorDesign #KALISTORIK
```

**链接：** 待补（发帖后抓取）
**互动：** 待 24h 后复查
