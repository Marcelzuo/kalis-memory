# KB 总目录

> 原则：只做入口。找内容先看本表定位，再进对应文件，不多读不少读。

## 顶层结构

| 目录 | 用途 |
|:--|:--|
| `kalistorik/` | KALIS TORIK 商业（品牌 + 社媒 + 客户 + 独立站） |
| `study/` | 学习（`luoyu/` 珞妤，妹妹以后并列） |
| `personal/` | 个人（旅游等） |
| `investment/` | 投资理财 |
| `ops/` | 团队通用（分工/备份/git/记忆/错误库） |
| `archive/` | 只读归档 |

## 商业 kalistorik/

| 文件 | 触发词 | 最新结论 |
|:--|:--|:--|
| `kalistorik/brand.md` | 品牌/颜色/字体/Logo | 2026-07-21 素材来源铁律 |
| `kalistorik/content.md` | 文案/红线/审查 | 2026-08-18 内容落地性铁律 |
| `kalistorik/deploy.md` | 部署/Cloudflare | 图片走阿里云法兰克福 |
| `kalistorik/site.md` | 独立站/SEO | — |
| `kalistorik/algorithm.md` | 算法/排名 | — |
| `kalistorik/social/rules.md` | 社媒/账号/发布 | 2026-07-21 FB 发布规范 |
| `kalistorik/social/plan.md` | 内容总纲 | V7.7 |
| `kalistorik/social/linkedin.md` | LI 发帖 | LI #22 已发 |
| `kalistorik/social/facebook.md` | FB 发帖 | FB #15 已发 |
| `kalistorik/social/instagram.md` | IG 发帖 | 冷启动 0 粉 |
| `kalistorik/social/data.md` | 社媒数据 | 2026-09-07 快照 |
| `kalistorik/clients/eu.md` | 欧洲客户 | — |
| `kalistorik/clients/row.md` | 其他客户 | — |
| `kalistorik/targets/li.md` | LI 目标 | — |

## 学习 study/

| 文件 | 触发词 | 最新结论 |
|:--|:--|:--|
| `study/luoyu/plan.md` | 珞妤/全科方案 | V2 |
| `study/luoyu/math.md` | 珞妤/数学错题 | — |
| `study/luoyu/english/novels.md` | 小说 | — |
| `study/luoyu/english/sop.md` | 小说流程 | — |

## 个人 personal/

| 目录 | 内容 |
|:--|:--|
| `personal/travel/` | 自驾游、地图 |

## 投资 investment/

| 文件 | 触发词 | 最新结论 |
|:--|:--|:--|
| `investment/INDEX.md` | 投资/A股/个股/ETF/美股/AI泡沫 | 2026-09-07 世纪华通清仓+2415；巨人600股待启动约30-35%；重筛可成交名单：生益科技/工业富联/香农芯创/莲花控股/炬光科技/千金药业/四方达 |

> 投资细分目录见 `investment/README.md`；个股/大盘原始行情按日期存 `investment/data/`。
## 团队 ops/

| 文件 | 触发词 |
|:--|:--|
| `ops/team.md` | 分派/兄弟 |
| `ops/git.md` | git/commit/分支 |
| `ops/backup.md` | 备份/检查点 |
| `ops/memory.md` | 记忆清理 |
| `ops/web-search.md` | 联网/搜索通道/内网外网/Clash/数据源 |
| `ops/sources.md` | 资料通道库/图片/视频/音乐/AI/行情/浏览器 |
| `ops/errors.md` | 错误库 |
| `ops/agents/mamen.md` | 玛门日志 |
| `ops/agents/lucifer.md` | 路西法日志 |
| `ops/work-log/` | 米迦勒工作日志 |

## 米迦勒自检

- 每得出新结论 → 立刻写入对应文件并更新本表。
- 写入后简报一句（≤2 行）。
