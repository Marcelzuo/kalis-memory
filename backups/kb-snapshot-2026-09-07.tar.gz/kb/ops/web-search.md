# 联网通道总规则（写死版 · 2026-09-03）

> 米迦勒/玛门/路西法三人强制共用。联网前先看本文件，不再凭感觉选通道。
> 老板原话：搜索通道很多，但要区分内网/外网——没开 Clash 只能走国内通道，开了 Clash 国内外都能走。
> 素材/图片/视频/音乐/AI 生图/浏览器通道见 `ops/sources.md`；本文件只管搜索与数据。

## 第 0 步：先判内网还是外网（必做，5 秒）

```bash
# 探测 Clash 是否开启（任一端口开=已开代理）
for p in 7890 7891 7897; do nc -z -w1 127.0.0.1 $p && echo "CLASH_OPEN:$p"; done
# 再查环境变量
env | rg -i 'proxy|clash'
```

| 判定结果 | 允许通道 |
|:--|:--|
| 全端口关 + 无 proxy 环境变量 | **纯内网**：只走国内通道，禁止访问 google/ddg/Reuters 等外网 |
| 7890 或 7891 开 | **外网可用**：`export https_proxy=http://127.0.0.1:7890` 后国内外都能走 |

> 结论：外网失败先查第 0 步，没开 Clash 就别试第二次，直接走国内。

## 一、国内通道（纯内网就用这些，全部实测可用）

### 搜索（查资讯/查观点/查规则）
- 首选搜狗：`curl -sL --max-time 10 -A "Mozilla/5.0" "https://www.sogou.com/web?query=<URL编码关键词>"`
- 百度备选：`curl -sL --max-time 10 -A "Mozilla/5.0" "https://www.baidu.com/s?wd=<关键词>"`
- 百度出安全验证码 → 换搜狗，不硬试。
- 必应 RSS：`https://www.bing.com/search?q=<关键词>&format=rss`

### A 股行情（数据源优先 opencli，K 线走新浪）
- 实时报价：`opencli eastmoney quote <6位代码> -f json`
- 主力资金榜：`opencli eastmoney money-flow --limit 100 -f json`
  - ⚠️ 榜单只返回前 N 名；**不在榜 ≠ 净流出**，只是金额小没进榜。要精确某只票的资金必须用单票资金接口（见下），禁止把“不在榜”当“资金不过”。
- 板块：`opencli eastmoney sectors -f json`
- 单票主力资金：`curl -s --max-time 10 -A "Mozilla/5.0" -H "Referer: https://quote.eastmoney.com/" "https://push2.eastmoney.com/api/qt/stock/fflow/kline/get?secid=<0.代码|1.代码>&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56&klt=1&lmt=1"`
- 日 K（120 根，算 MA/MACD 用）：`curl -s --max-time 10 -A "Mozilla/5.0" "https://quotes.sina.cn/cn/api/jsonp_v2.php/var%20_=/CN_MarketDataService.getKLineData?symbol=<sz|sh+代码>&scale=240&ma=no&datalen=120"`
  - 沪市 6 开头 = `sh+代码`；深市 0/3 开头 = `sz+代码`。
- 指数实时：`curl -s --max-time 10 -H "Referer: https://finance.sina.com.cn/" "https://hq.sinajs.cn/list=sh000001"`（注意 GBK 编码）

### 财经资讯/研报/公告
- 东财资讯搜索 API：`https://search-api-web.eastmoney.com/search/jsonp?cb=&param=<搜索参数>`（研报用 `code=` 过滤）
- 财联社 `cls.cn`、证券时报 `stcn.com`、每日经济新闻 `nbd.com.cn`、第一财经 `yicai.com`、新浪财经 `finance.sina.com.cn`、同花顺 `10jqka.com.cn`、雪球 `xueqiu.com`（雪球需 token，失败换东财/同花顺）。
- 官方：证监会/央行/财政部/统计局/发改委/上交所/深交所/巨潮资讯 `cninfo.com.cn`。

## 二、外网通道（只在开 Clash 后可用）

- 通用搜索：Google、DuckDuckGo、Bing 国际。
- 财经：Reuters、Yahoo Finance、CNBC、Investing.com、TradingEconomics、FRED。
- 官方：美联储、美国财政部、BEA、BLS、IMF、世界银行、OECD、ECB。
- 智库：NBER、Brookings、PIIE、Rhodium Group。

## 三、写死禁止（以后谁都不许再走这些路）

| 禁止项 | 原因 |
|:--|:--|
| 未开 Clash 时访问 Google/DDG/Reuters 等外网 | 必超时，白等 |
| 东财 `push2his.eastmoney.com` 的 K 线接口 | 已断，返回 0 字节 / fetch failed |
| `claude` 里的 WebSearch/WebFetch 工具 | 模型路由不支持，报 unrecognized_model 或卡住 |
| `sleep N` 重试循环（如 sleep 12 × 5） | 一个空返回源会拖十几分钟，是卡死元凶 |
| 同一失败源反复重试 | 失败 1 次即换源，最多试 2 个不同源 |
| 裸调 `opencli` AI 源（doubao 等） | 依赖 Chrome 插件，未确认可用前禁止 |
| Pexels 搜索页直接 curl | 403（带 UA/代理也 403），图片走 CDN 直链（见 `ops/sources.md`） |
| 简单任务用 Pro 模型 | 慢 + 烧额度；找图/下载类用 Flash（见 `ops/team.md`） |

## 四、统一超时与纪律（三条硬线）

1. 每条 `curl` 必须带 `--max-time 10`（搜索/大页面可 15）。
2. 同一源失败 1 次 → 换源；2 个不同源都失败 → 报米迦勒，不再空转。
3. 数据类任务：K 线走新浪、实时/资金走 opencli；禁止自己写 `curl` 直连 `push2his`。

## 五、派工模板（米迦勒派玛门/路西法做联网任务时，任务里必须附这段）

```
【联网铁律】先跑第0步探测 Clash；没开 Clash 只用国内通道。
搜索用搜狗/百度 curl（--max-time 10）；行情用 opencli eastmoney；K线用新浪；禁止 push2his、禁止 WebSearch/WebFetch、禁止 sleep 重试循环。同一源失败1次即换源，2次失败报米迦勒。
```
