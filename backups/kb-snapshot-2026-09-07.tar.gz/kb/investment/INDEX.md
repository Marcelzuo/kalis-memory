# 投资 INDEX（唯一入口）

> 用法：先看触发词，跳到精确文件；文件里找不到再回本表。不多读不少读。
> 当前只列“生效文件”；历史/否决/过程稿全部进 `archive/`，默认不读。

## 最快路径

| 要找什么 | 文件 |
|:--|:--|
| 投资规则第一标准/最高执行标准/冲突裁定/口径附录/移动止盈/熔断/仓位折中 | `strategies/stock/rules-master.md` |
| 实盘买卖/真实持仓/交易台账/已平仓记录 | `trades/`（`trades/README.md` 入口） |
| 今天/当前候选、触发价、盯盘 | `strategies/active/current-watchlist.md` |
| 操作规则/止损止盈/换股/仓位/持仓周期/过周末/突破触发 | `strategies/stock/rules-operation.md` |
| 条件移动止盈/先清半仓/剩余半仓硬锚点/尾盘复核 | `strategies/stock/conditional-trailing.md` |
| 个股规则/选股/市值带/突破即进/技术优先/盈亏比≥2 | `strategies/stock/rules-stock.md` |
| 大盘规则/仓位分级/大盘走弱/MA5/MA20/生命线 | `strategies/market/china-policy-hotspot.md` |
| 规则迭代/复盘教训/今天学到什么 | `strategies/stock/lessons-log.md` |
| 留存/归档/清理/每日整理 | `RETENTION.md` |
| 今日完整投资过程复盘与优化/决策链/关键信息点 | `analysis/2026-09-02-process-review.md` |
| 今日收盘复盘/早盘预测对账/农业不接力/空仓正确 | `analysis/2026-09-02-close-review.md` |
| 今日收盘复盘/世纪华通买点归因/次日预测/市值硬过滤 | `analysis/2026-09-03-close-review.md` |
| 今日盘前三兄弟建议/大盘压力支撑/世纪华通 14.84/过周末减仓 | `analysis/2026-09-04-preopen.md` |
| 今日收盘复盘/世纪华通 15.90 卖 800/巨人 27.97 买 400/卖强不追高 | `analysis/2026-09-04-close-review.md` |
| 换股候选/卖半仓后资金去向/三兄弟选股/海联金汇/通达电气/两仓冲突 | `strategies/active/current-watchlist.md` |
| 今日全量候选五关重筛/市值过关执行池/入场触发 | `analysis/2026-09-02-full-screen.md` |
| 今日盘前/开盘第一次分析/隔夜外盘/三情景/操作细节 | `analysis/2026-09-03-preopen.md` |
| 美股/AI 泡沫长期结论 | `analysis/2026-08-25-us-ai-bubble.md` |
| ETF 长期组合与收益测算 | `strategies/etf/2026-08-25-etf-strategy.md` |
| 国外机构/投行对 A股+房地产观点汇总 | `data/research/2026-08-30-foreign-institutions-china-outlook.md` |
| 投资数据源总表 | `data/research/sources.md` |
| 个股/指数原始行情快照（近 2 日） | `data/quotes/`、`data/market/` |
| 查询/搜索台账模板 | `data/ledger/trade-journal-template.md` |
| 历史/否决/过程稿 | `archive/` |

## 触发词

| 触发词 | 文件 |
|:--|:--|
| 第一标准/最高规则/冲突裁定/口径附录/移动止盈/熔断15/20/仓位折中/量比口径/前高H/ATR14 | `strategies/stock/rules-master.md` |
| 止损/止盈/换股/仓位/操作/每日重筛/持股时长/过周末/候选池失效线/剔除/期望值/交易台账/样本量/突破触发/大盘背景/压力测试 | `strategies/stock/rules-operation.md` |
| 条件移动止盈/先清半仓/剩余半仓硬锚点/尾盘复核 | `strategies/stock/conditional-trailing.md` |
| 选股/个股/市值带/技术硬门槛/盈亏比≥2/突破即进/技术优先/入场三问/期望值门槛/ATR/量比/RSI/回测 | `strategies/stock/rules-stock.md` |
| 大盘/仓位分级/大盘走弱/MA5/MA20/生命线/涨停潮 | `strategies/market/china-policy-hotspot.md` |
| 教训/复盘/T+1/不接飞刀/规则迭代/和胜放量 | `strategies/stock/lessons-log.md` |
| 留存/归档/清理/过期数据/每日整理 | `RETENTION.md` |
| 实盘/买入记录/持仓跟踪/交易台账/平仓/盈亏/世纪华通成交 | `trades/` |
| 当前观察排序/泰凌微/唯万/华策/和胜/神农/隆平/市值剔除 | `strategies/active/current-watchlist.md` |
| 今日完整投资过程/优化结论/关键信息点 | `analysis/2026-09-02-process-review.md` |
| 今日收盘复盘/早盘预测对账/农业不接力/空仓正确 | `analysis/2026-09-02-close-review.md` |
| 今日全量候选/五关重筛/入场触发 | `analysis/2026-09-02-full-screen.md` |
| 今日盘前/隔夜外盘/三情景 | `analysis/2026-09-03-preopen.md` |
| 今日收盘复盘/世纪华通买点归因/次日预测/市值硬过滤 | `analysis/2026-09-03-close-review.md` |
| 今日盘前三兄弟建议/大盘压力支撑/世纪华通 14.84/过周末减仓 | `analysis/2026-09-04-preopen.md` |
| 今日收盘复盘/世纪华通 15.90 卖 800/巨人 27.97 买 400/卖强不追高 | `analysis/2026-09-04-close-review.md` |
| 今日资金口径/集中不分散/T+1止损/大盘分级/低吸原则/世纪华通买点/尾盘不是唯一买点 | `discussions/2026-09-03-decisions.md` |
| 美股/AI 泡沫/经济危机/看空 | `analysis/2026-08-25-us-ai-bubble.md` |
| ETF/定投/5年/10年收益 | `strategies/etf/2026-08-25-etf-strategy.md` |
| 国外投行/外资观点/海外 A股展望/海外房地产展望 | `data/research/2026-08-30-foreign-institutions-china-outlook.md` |
| 数据源/权威网站/基金官网/来源分层 | `data/research/sources.md` |
| 历史数据/原始行情/个股查询记录 | `data/quotes/`、`data/market/` |
| 旧方案/已否决/历史版本 | `archive/` |

## 铁律

1. 每次查个股/指数行情 → 必须落盘到 `data/quotes/YYYY/MM/YYYY-MM-DD/` 或 `data/market/YYYY/MM/YYYY-MM-DD/`。
2. 新结论 → 先写对应文件，再更新本表；旧版移 `archive/`，不保留重复版本。
3. 当前状态只放 `strategies/active/`；`data/` 只存原始快照；`strategies/` 只存规则；`discussions/` 只存决策过程；历史一律进 `archive/`。
4. 每日收盘后：清理冗余、剔除否决项、只留终版，并同步本表。
