# 投资备忘录 · 留存与归档规则

> 目的：该留的留，该删的删，该压缩的压缩。复盘靠“决策链 + 关键数据快照”，不靠堆积原始文件。

## 分层保留

| 层 | 目录 | 保留策略 |
|:--|:--|:--|
| 策略（规则） | `strategies/` | 只留最新版；旧版移入 `archive/`，30 天后删除 |
| 当前状态 | `strategies/active/` | 永远只留 1 份，实时更新 |
| 决策/讨论 | `discussions/` | 重大决策长期保留；普通过程日志 12 个月后压缩 |
| 复盘结论 | `analysis/` | 长期保留，是策略演进的证据链 |
| 原始数据 | `data/quotes/`、`data/market/` | 盘中明细 7 天 → 日摘要；日摘要 12 个月 → 月汇总 |
| 研究素材 | `data/research/` | 12 个月后压缩；标记“长期参考”的例外 |
| 归档区 | `archive/` | 30 天后压缩，6 个月后清理，除非标记 keep |

## 压缩 / 删除规则

- 压缩：多份原始快照合并成带索引的摘要文件（时间、价格、涨跌、量能、资金、事件），原始文件删除。
- 策略旧版：新策略落盘即把旧版移到 `archive/`，30 天后无引用即删。
- 股票数据：即使不再关注也保留，作为策略变更的重要参考。
  - 盘中 tick 明细：7 天。
  - 每日收盘摘要：12 个月。
  - 月汇总：3 年。
- 更久：只留季度/年度索引。

## 每日整理（2026-08-27 起 · 今日事今日毕）

- 每天收盘复盘后，按“该清的清、该整合的整合、该分类的分类”梳理一遍，不让冗余堆积。
- 只留终版：同一只股票/同一结论，当天多次预测只留最后一版，旧版移 `archive/`；30 天后无引用删除。
- 剔除否决项：被否决的想法/方案不留在决策区，若教训有用只写一句进 `lessons-log.md`。
- 三个兄弟分区各自复查：个股规则/操作规则/大盘规则不混放；重复条款并入唯一文件。
- 收工前自查：`INDEX.md` 触发词与现存文件一一对应，删除失效链接。
- 整合原则（2026-08-28 起）：新观点/新想法一律并入 `strategies/` 现有 canonical 文件（`rules-stock.md`/`rules-operation.md`/`china-policy-hotspot.md`），不因一个想法新开文件；旧版移 `archive/`，只留终版，`INDEX.md` 同步更新。

## 当前状态（2026-09-02）

- 现行规则（分三类）：
  - 大盘规则：`strategies/market/china-policy-hotspot.md`
  - 个股规则：`strategies/stock/rules-stock.md`
  - 操作规则：`strategies/stock/rules-operation.md`
  - 当前观察池：`strategies/active/current-watchlist.md`
  - 迭代日志：`strategies/stock/lessons-log.md`
- 今日完整过程复盘：`analysis/2026-09-02-process-review.md`
- 今日收盘复盘：`analysis/2026-09-02-close-review.md`
- 今日盘前/盘中：`analysis/2026-09-02-preopen.md`、`analysis/2026-09-02-full-screen.md`
- 长期结论：`analysis/2026-08-25-us-ai-bubble.md`、`data/research/2026-08-30-foreign-institutions-china-outlook.md`

## 待清理

- 已完成（2026-09-02 收工）：08-26 至 09-01 的每日分析、旧讨论、旧原始行情与研究草稿已移 `archive/`；`INDEX.md` 已只保留生效文件。
- `strategies/stock/2026-08-25-trading-playbook.md` 已移 `archive/strategies/`，旧内容不重复保留。
- `data/quotes/2026/09/2026-09-01/`、`data/market/2026/09/2026-09-01/` 为昨日原始快照，明日收盘后可归档。
