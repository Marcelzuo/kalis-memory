# 投资数据区

> 只放原始快照与数据源；结论在 `analysis/`，规则在 `strategies/`。

## 保留原则
- `data/quotes/`、`data/market/`：默认只保留最近 2 个交易日的原始快照。
- 旧原始数据移 `archive/data/`，不删除核心研究结论。
- `data/research/` 只保留长期研究汇总与 `sources.md`；个人草稿/过程稿移 `archive/`。
- `data/ledger/trade-journal-template.md` 为交易台账模板，长期保留。
