# 撒旦工作日志

> ⛔ **2026-08-31 起已退出。** 本文件为历史存档，不再作为派工依据。现役三人分工见 `ops/team.md` 最高规则。

> 浏览器 · GUI · 截图 · 数据采集 · A 股技术复盘。调度来自米迦勒，红线：出方案报批，不直接操作账号发帖。
> 日追加、周瘦身、错即录。详细 SOP 见 `ops/team.md` § 2。

## 2026-08-30 · 入口合并

**结论：** 撒旦入口合并为唯一 OpenClaw；重复的 Hermes `satan` profile 已停用并归档。
**产物路径：** `~/.hermes/backups/satan-profile-20260830`（profile）、`~/.hermes/backups/satan-alias-20260830`（alias）
**下一步：** 不再使用 `hermes -p satan`；模型已切 `qwen3.8-max`

## 🧰 资产 & 能力

| 能力 | 工具/方式 | 备注 |
|------|-----------|------|
| 浏览器操作 | Chrome 已登录态（持久化） | opencli browser · AppleScript |
| 数据采集 | GA4 / LI / FB / IG / 东财 / 新浪 | 已登录免认证；东财 quote 故障时用新浪回退 |
| 5min / 日 K | `eastmoney kline --period 5m/day` | 实测可用 |
| GUI 跨应用 | Computer Use（截图→视觉→动作） | 兜底手段 |
| 表单填写 | 浏览器自动化 | 仅连通性测试，不存账号 |

## ⚠️ 已知限制（派工前必查）

- **FB 专业面板** 常 404 → 备选 Meta Business Suite
- **IG 纯 JS 渲染** → innerText 仅基础信息，深度数据走人工
- **LI 新帖展示量** 延迟 24h
- **东财 quote / index-board** 偶发 fetch failed → 新浪 hq.sinajs.cn 回退（见 `invest/data/research/sources.md`）

## 🚧 红线

- 出方案报批 → **不直接操作账号发帖**（含 FB/IG/LI/雪球/东财等所有平台）
- 不删业务代码/配置/账号（自清洁仅动 cache + 任务产物）
- 不动 `~/Marcelzuo/kalis-memory` 与 KB 业务文件（除自身 satan.md）
- 压缩归档优先，不直接删

## 📅 工作记录

### 2026-08-28 周五 · A 股技术复盘首单

- 核心 3 复盘 → `invest/data/research/2026/08/2026-08-28/satan-technical.md`
- 视频交易心理意见 → `.../video-satan-opinion.md`
- 量化最小手册初稿 → `.../quant-satan-draft.md`
- 数据源：东财 kline（60 日 + 5min）+ 新浪实时
- 关键判断：**招金黄金形态最干净**（盘中洗盘拉回 + 多头排列 + RSI 健康）；**先放弃**：泰凌微（假突破）/ 和胜（已到目标）
- KB 触发词：技术/复盘/MA/RSI/形态 → `invest/strategies/stock/rules-stock.md`

### 2026-08-25 周二 · 看空情绪调研（论坛线）

- 标的：reddit / hackernews / xueqiu / zhihu / reuters / bloomberg
- 产出：`/tmp/satan-research-20260825/findings.md`（317 行）
- 关键：知乎看空压倒性 + BIS/桥水/ECB/Taiwan 央行警告
- 失败：xueqiu 需登录、reddit 临时 HTML 故障、bloomberg news 空返回

### 2026-07-21 周二 · 建档

- 日志框架 + team.md 边界校对；首日无产出

## 📊 历史产出索引（按主题归档到 KB）

| 主题 | 路径 | 备注 |
|------|------|------|
| A 股技术复盘 | `invest/data/research/YYYY/MM/YYYY-MM-DD/satan-*.md` | 日频 |
| 论坛情绪调研 | `kalistorik/research/YYYY-MM-DD-*.md`（待建）/ `/tmp/satan-research-*/findings.md` | 单次任务 |
| 量化手册 | `invest/data/research/YYYY/MM/YYYY-MM-DD/quant-satan-draft.md` | 季度 |

## 🔧 自清洁 checklist（每周一次）

- [ ] 浏览器 cache：`~/.openclaw/browser/openclaw/user-data/{GrShaderCache,ShaderCache,GPUCache,Dawn*,Graphite*,AutofillAiModelCache}`（≥7 天）
- [ ] 浏览器 metrics：`BrowserMetrics-spare.pma`
- [ ] `~/.openclaw/workspace/coordination/` > 50 文件必归档
- [ ] 本日志超过 200 行 → 拆出历史到 `archive/agents/`
- [ ] 报告完成 → `/tmp/satan-*` 任务产物可清
