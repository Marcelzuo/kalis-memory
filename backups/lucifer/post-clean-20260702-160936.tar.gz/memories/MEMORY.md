# MEMORY · 路西法 v5 (2026-07-02 清洁)

## 触发词速查
- 女儿/错题/左珞妤/数学 → 见"左珞妤 SOP"段；4 列错因表+每题 3 道新题+DOCX 落桌
- KALIS TORIK / kalistorik → 见"品牌"段；金线 #C9A96E
- LinkedIn 触达 → 见"LinkedIn 范本"段
- Vision 401 / OCR → 见"故障/OCR"段
- 审查/代码/视觉 → 见 SOUL.md（不在本文件重复）

## 角色矩阵(2026-07-01)
路西法 v5 = ①审查官 ②撰稿人(长文/报告) ③品牌运营大脑。
不写代码(玛门领)、不直接截图(撒旦领)、不部署(米迦勒领)。
可独立写 markdown/长文/报告/分析。撰稿守品牌红线+老板原则。

## 审查标准
代码 5 项: 逻辑/架构/安全/需求覆盖/风格。视觉 4 件套: HTTP200/naturalWidth>0/CSS规则/截图。
不通过→驳回原开发者。10min超时→米迦勒直审。**学习资料再加:章节匹配女儿实际进度(2026-06-29 老板训话扩为 6 项)**。

## 学习资料铁律(2026-06-29 老板训话)
关乎女儿/学习/教育的输出: 5 项审查 + 双重验算(sympy + 手算)。交稿前自审:① 逻辑:数学/事实双重验算 ② 架构:题型分布合理难度递进 ③ 安全:无敏感信息外泄(KALIS/CIF/价格/联系) ④ 需求覆盖:题面+答案+详解+验证+常见错 5 要素齐全 ⑤ 风格:统一术语/格式/问号结尾 ⑥ **章节匹配女儿实际 OCR 实测进度**。误人子弟 = 0 容忍。

## 选择项呈现铁律(2026-06-29 老板原话)
A/B/C/D 选择项**必须**用 Markdown 列表直接写在对话里,绝不调用 `clarify` 工具(老板看不到对话框)。`clarify` 仅用于开放式"告诉我更多"。

## 品牌 KALIS TORIK
金线 #C9A96E 最上→KALIS→TORIK。色 #000/#FFF/#C9A96E/#888。字 Montserrat。
AI味=失信。脱敏:人名/脸/公司名必处理。图片优先免版权。
主域 kalistorik.com(镜像 kalistorik.pages.dev,Cloudflare Pages)。canonical/og:url/sitemap 指向主域。

## LinkedIn 首次触达范本(2026-06-28)
"Hi Mark, this is Kalis Torik. With over 20 years in furniture trade, we have extensive factory resources in China, offering factory vetting, in-line QC and full shipment support to resolve sourcing issues for clients. Happy to connect if you have any China furniture sourcing needs." (~60词)
骨架:Hi {名}, this is Kalis Torik. With over X years in {品类} trade, we have {资源} in China, offering {服1}, {服2} and {服3} to resolve {痛点}. Happy to connect if you have any China {品类} sourcing needs.
6 铁律:① 'this is Kalis Torik' 直出场 ② 顺序=年限品类→资源→3服务→收尾邀请 ③ 'we have' 非 'we help' ④ 禁行话(LCL/FCL/incoterms) ⑤ 不对标对方 ⑥ 收尾用 'Happy to connect if you have any ... needs'。
三不:不提名品类/服务细节/20+年——P2P 招呼非 B2B 推销。仅首次 connection request+短消息,跟进另写。

## 故障/OCR
- **Vision API 401 持续(本 profile)**: vision_analyze 持续 401 鉴权失败(API secret key missing)。女儿学习照片 OCR 走本地: tesseract chi_sim+eng + Swift Vision.framework + marker-pdf。**手写体数学公式识别率几乎为 0**,对混合文档必须 PIL 抹手写像素后 OCR,或走"只提取红黑笔位置"路径。
- **marker-pdf 已装(2026-06-29)**: venv `/tmp/marker_venv/`(Python 3.12,homebrew 必需),命令 `/tmp/marker_venv/bin/marker_single <img.jpg> --output_dir <out>`。模型缓存 `~/.cache/huggingface/`(已下 2.5GB+ surya+texify)。LaTeX 还原 80-90%,**关键数字必须人工核对**。8-280 秒/张(CPU),推荐先 PIL 抹红黑笔提速提准。
- **卡死上报**: 退出码 0完成/1失败/2卡死 → [BLOCKED] 格式上报米迦勒。

## 女儿数学进度 OCR 实测(2026-06-29)
女儿**实际在做高中/竞赛题**(原"初二+平方差/完全平方"已废):① 4次方换元 (x+5)⁴+(x+3)⁴-82 ② 连乘 4 因式 x(x+1)(x+2)(x+3)-8 ③ 立方和 (1/6 x⁴)³+(1/3 c)³ ④ 多项式因式求参 9x²+3x+3m 含因式 3x-1 求 m。
**铁律**: 永远 OCR 第一手原题,不信 MEMORY 推测;OCR 出来先列关键词反查章节再出题。MEMORY 是 hint 不是 ground truth。

## 左珞妤错题任务 SOP(2026-06-29 7 步)
老板私人事务,**只路西法处理,不进撒旦/玛门/米迦勒派工流**。位置: `~/.openclaw/workspace/coordination/zuoluo-math/`(LOG+INDEX+assets) + `~/.hermes/backups/zuoluo-math/`(独立备份)。协调仓只放指针 `zuoluo-math-LINK.md`。
7 步:① 照片 ② OCR ③ 提错题 ④ 4 列错因(题号/题目/错因/正确答案) ⑤ 题型归纳 ⑥ 每题型 3 新题(难度>原题) ⑦ 答案+详解 → DOCX 落桌(不绕 PDF,题答分页)。
技术要点: 答案计算放 Python(dump JSON),格式化放 Node docx-js(读 JSON),解耦数学正确性与排版。N>1 轮**不重做前轮讲解**,直接读原文件定位题型按类聚类出 3 道更新更难的新题,文件名加 "_第N轮"。
**文件主语铁律(2026-06-29)**: DOCX 第 1 页=题干+作答+答案+错因(女儿视图);第 2-3 页=新题练习;工具/统计/方法论**不进女儿文件**(那是给老板的报告)。

## KALIS TORIK site 审查(2026-06-29/30)
- P0 全过
- P1 schema 部分过: 3 script 块未合并成 @graph + @id 串联 → 已报老板待决策
- 6 语言 140 键一致(JS 切换)/ 22 个 @media 断点 / 0 JS 错误 / H1=1 H2=10
- 全站 6 语言 HTTP 200 / 控制台干净 / 0 broken 图片

## 维护
自清洁: session检查/log轮转/cache清理/git pull。备份: 完成任务后+>24h → `~/.hermes/backups/`。
§

## 本机图片/AI超分栈盘点(2026-07-02)
**有** GIMP.app(/Applications/GIMP.app,brew+gimp-console-3.2 脚本接口)+ ffmpeg(brew,scale=lanczos 强插值)+ Canva.app + wpsoffice.app。
**Python** torch 2.8.0(Apple Silicon MPS=True)+ opencv-python 4.11 + pillow 10.4 + transformers 4.57 + scipy。
**无** ImageMagick/GraphicsMagick/libvips/basicsr/realesrgan/waifu2x/cugan。
**已跑通 Real-ESRGAN**:venv /tmp/realesrgan-venv (Python 3.9,因 realesrgan 0.3.0 pin llvmlite<0.37),--no-deps 装 realesrgan+basicsr+torch+cv2+scipy+pyyaml,patch basicsr/data/degradations.py 的 torchvision.transforms.functional_tensor → functional。模型 RealESRGAN_x4plus.pth 放 /Users/zuo/.realesrgan/(67MB,github release),MPS 推理 4×约 6s。
案例: Desktop/1.webp 749×406 → 4×(2996×1624) → resize 1200×650,产物 Desktop/1_upscaled.webp,vs ffmpeg lanczos 基线边缘能量 21→34(+60%)。脚本 /tmp/upscale_1.py 可复用。

## AI 超分成熟配方(2026-07-02 已验证)
1) uv venv /tmp/realesrgan-venv --python 3.9
2) VIRTUAL_ENV=... uv pip install --no-deps realesrgan basicsr;再 uv pip install opencv-python-headless torch torchvision scipy numpy requests tqdm pyyaml
3) sed -i '' 's/torchvision.transforms.functional_tensor/torchvision.transforms.functional/' /tmp/realesrgan-venv/lib/python3.9/site-packages/basicsr/data/degradations.py
4) curl RealESRGAN_x4plus.pth → /Users/zuo/.realesrgan/
5) net = RRDBNet(3,3,64,23,32,4); state = torch.load(...); state = state.get('params_ema',state); net.load_state_dict(state); net.to('mps')
6) tile-推理 256px overlap 8,torch.no_grad
7) cv2.resize 到目标宽度 INTER_LANCZOS4 + PIL.save(out,'WEBP',quality=92)
**快捷版**(只要传统插值):ffmpeg -i in.webp -vf "scale=1200:-2:flags=lanczos" out.png,3秒搞定。
