---
name: image-upscale-pipeline
description: macOS 图片放大两路方案——ffmpeg lanczos 快速版(纯插值,数秒成)与 Real-ESRGAN 4× AI 超分版(MPS 6s/张,边缘细节大幅提升)。覆盖 Python 3.9 venv 搭 esrgan、basicsr torchvision API 兼容补丁、模型下载路径、tile 推理、PIL/WebP 输出。
---

# macOS 图片放大流水线(2026-07-02 实战)

## 何时用
- 给老板放大的产品图、设计稿、截图 ≥1200 宽做展示
- ai超分场景下比传统插值(锐度/细节)显著好
- 需要把 WebP/PNG/JPG 任意源放大到目标尺寸

## 师傅工具决策
| 需求 | 用什么 | 速度 | 质量 |
|------|--------|------|------|
| 1.6×~2× 普通插值就够 | `ffmpeg` | 3 秒 | 传统 lanczos,边缘能量 ~21 |
| 2×~4× 要细节 | Real-ESRGAN 4× | ~10 秒 | AI,边缘能量 ~34(+60%) |
| 局部精修、人像磨皮 | GIMP.app | 手工 | 看人 |
| 在线模板/海报 | Canva.app | 在线 | 需联网 |

## 路由 A — ffmpeg 快速版(默认,推荐先试)
```
ffmpeg -hide_banner -loglevel error -y \
  -i 输入.webp -vf "scale=1200:-2:flags=lanczos" 输出.png
# -2 = 算高度时保证宽高比偶数,免 chroma subsample 问题
```
- 适用: 任何格式(webp/png/jpg/tif → webp/png),放大比例 ≤4×
- 优点: 零依赖、3 秒、不掉色
- 缺点: 像素不会变多,只是插值,锐度本质不变

## 路由 B — Real-ESRGAN AI 4×(本机已搭好)
环境已就绪,直接复用:
- venv: `/tmp/realesrgan-venv` (Python 3.9)
- 模型: `/Users/zuo/.realesrgan/RealESRGAN_x4plus.pth` (67MB, x4plus 通用版)
- 推理脚本模板: `/tmp/upscale_1.py`

### 标准调用
```bash
/tmp/realesrgan-venv/bin/python /tmp/upscale_1.py
# 需修改脚本里的 INPUT / OUTPUT / target_w 三个变量
```

### 脚本骨架(可直接复用)
```python
import torch, cv2, numpy as np
from PIL import Image
from basicsr.archs.rrdbnet_arch import RRDBNet

net = RRDBNet(3, 3, 64, 23, 32, 4)
state = torch.load('/Users/zuo/.realesrgan/RealESRGAN_x4plus.pth', map_location='cpu')
if 'params_ema' in state: state = state['params_ema']
net.load_state_dict(state, strict=True).eval().to('mps')

arr = np.array(Image.open(INPUT).convert('RGB'))
x = torch.from_numpy(arr).permute(2,0,1).float().unsqueeze(0).to('mps') / 255.
tile_size, overlap = 256, 8
b, c, h, w = x.shape
out = torch.zeros((b, c, h*4, w*4), dtype=x.dtype, device='mps')
for ty in range(0, h, tile_size-overlap):
    for tx in range(0, w, tile_size-overlap):
        sh = min(tile_size, h-ty); sw = min(tile_size, w-tx)
        tile = x[:,:,ty:ty+sh, tx:tx+sw]
        out[:,:,ty*4:(ty+sh)*4, tx*4:(tx+sw)*4] = net(tile)
y = (out.squeeze(0).clamp(0,1).cpu().numpy().transpose(1,2,0) * 255).astype(np.uint8)
# 4× 出图后降采样到目标宽度,质量优于直插值
resized = cv2.resize(y, (1200, int(y.shape[0]*1200/y.shape[1])), interpolation=cv2.INTER_LANCZOS4)
Image.fromarray(resized).save(OUTPUT, 'WEBP', quality=92)
```

## ⛔ 四个踩过的坑(必读)
1. **`basicsr` 启动即 import 数据管线**,用了 torchvision 老版私有 API `functional_tensor`,新 torchvision(0.23+)没这路径。patch:
   ```
   sed -i '' 's/torchvision.transforms.functional_tensor/torchvision.transforms.functional/' \
     /tmp/realesrgan-venv/lib/python3.9/site-packages/basicsr/data/degradations.py
   ```
2. **`realesrgan 0.3.0` pin 了 llvmlite<0.37**,Python 3.12 装不上 llvmlite 0.36。**必须用 Python 3.9 venv**。
3. **`--system` / `pip install` 撞 system-managed-external env 会死**,uv 也卡 `cycler-0.12.1` mkdir。**必须 venv 隔离**。
4. **官方权重 `.pth` 用 `params_ema` 包了一层**:`state = state.get('params_ema', state)`,否则少 key 全套不匹配。

## 客观验证手法
- 边缘能量对比:PIL FIND_EDGES 滤镜 + numpy.mean。21(基线)→ 34(4× 后降采样)即 +60% 标志成功。
- 平均像素差:同尺寸两张图 `np.abs(a-b).mean()`,10 左右合理;>30 提示过度;
- 文件体积:AI 版常是源 2-4×,存 WebP quality 92 适中。

## ⛔ 我不能干的
- 玛门的领地 = HTML/CSS/JS,我不改
- 撒旦的领地 = 浏览器/截图,我不开
- 这条 skill 是**reusable 工具链**,不是项目 ledger,不走品牌网站
